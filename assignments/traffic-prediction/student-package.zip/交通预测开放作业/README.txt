交通状态预测作业数据包 v2

阅读“作业任务书.txt”了解任务。可以使用本包数据，也可以选择其他公开数据集。

数据
METR-LA，20个监测点，2012-03-01 00:00至2012-03-28 23:55，5分钟间隔，速度单位mph。
保留原始列顺序的前20个监测点，按固定日期截取；未根据预测表现筛选。

文件
• data/speed_raw_mph.csv：时间为行、监测点为列的原始速度子集。
• data/traffic.npz：相同数据的NumPy格式，键为speed_raw、timestamps、sensor_ids。
• data/sensors.csv：监测点ID、纬度和经度。
• data/provenance.json：来源、原始文件指纹、截取方式及文件校验值。
• config.json：过去12步预测未来6步、8:1:1划分比例等任务参数。
• data_utils.py：数据读取与六步最近值预测辅助函数。

本包未填补缺失值、未标准化、未代为划分训练/验证/测试集。请自行检查并处理数据。METR-LA常用评价约定将零值视为缺失，请结合数据说明明确采用的规则，并保留目标有效性标记。
原始时间标签无时区信息，本包原样保留。数据按5分钟网格对齐。

读取
安装NumPy后可执行 python data_utils.py 查看数据规模。
from data_utils import load_data, persistence_forecast
speed, timestamps, sensor_ids = load_data()
# speed为[时间,监测点]；数据清洗、时间划分和样本构造由学生完成。
# persistence_forecast(last_values)将当前值重复6次，返回[...,6]。

数据来源
METR-LA与PEMS-BAY：https://github.com/liyaguang/DCRNN
论文：Diffusion Convolutional Recurrent Neural Network: Data-Driven Traffic Forecasting，ICLR 2018，https://arxiv.org/abs/1707.01926
LargeST：https://github.com/liuxu77/LargeST
PeMS03/04/07/08：https://github.com/Davidham3/STSGCN
本包提供监测点坐标；路网关系可自行获取并用于探索。
