"""Raw data loading and a six-step persistence baseline."""
from pathlib import Path
import numpy as np

def load_data():
    with np.load(Path(__file__).resolve().parent/'data/traffic.npz', allow_pickle=False) as d:
        return d['speed_raw'].copy(), d['timestamps'].copy(), d['sensor_ids'].copy()

def persistence_forecast(last_values, steps=6):
    """Repeat each latest observation across the forecast dimension."""
    if steps < 1:
        raise ValueError('steps must be positive')
    return np.repeat(np.asarray(last_values)[..., None], steps, axis=-1)

if __name__ == '__main__':
    speed, timestamps, sensors = load_data()
    print('Shape [time, sensors]:', speed.shape)
    print('Time:', timestamps[0], 'to', timestamps[-1])
    print('No imputation or split has been applied.')
