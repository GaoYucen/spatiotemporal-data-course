"""Build standalone teaching studio; all assets embedded, Python stdlib only."""
from pathlib import Path
import json
import ast
from demo import run
P=Path(__file__).resolve().parent


def build(speed=12,gap=120):
    source=P/'src'
    python=(P/'teaching_algorithms.py').read_text(encoding='utf-8')
    lines=python.splitlines()
    bundle={}
    for node in ast.parse(python).body:
        if not isinstance(node,ast.FunctionDef): continue
        actions={}
        highlights={}
        for child in ast.walk(node):
            if isinstance(child,ast.Call) and isinstance(child.func,ast.Name) and child.func.id=='emit' and child.args and isinstance(child.args[0],ast.Constant):
                actions[child.args[0].value]=child.lineno-node.lineno+1
        for parent in ast.walk(node):
            for field in ('body','orelse'):
                statements=getattr(parent,field,[])
                if not isinstance(statements,list): continue
                for index,statement in enumerate(statements):
                    if not isinstance(statement,ast.Expr) or not isinstance(statement.value,ast.Call): continue
                    call=statement.value
                    if not isinstance(call.func,ast.Name) or call.func.id!='emit' or not call.args or not isinstance(call.args[0],ast.Constant): continue
                    selected=list(range(statement.lineno,statement.end_lineno+1))
                    if index:
                        previous=statements[index-1]
                        is_record=isinstance(previous,ast.Expr) and isinstance(previous.value,ast.Call) and isinstance(previous.value.func,ast.Name) and previous.value.func.id=='emit'
                        if isinstance(previous,(ast.Assign,ast.AugAssign,ast.AnnAssign,ast.Expr)) and not is_record:
                            selected=list(range(previous.lineno,previous.end_lineno+1))+selected
                    highlights[call.args[0].value]=[line-node.lineno+1 for line in selected]
        bundle[node.name]={'highlights':highlights,'start' :node.lineno,'lines':lines[node.lineno-1:node.end_lineno],'actions':actions}
    payload='const CODE_BUNDLE='+json.dumps(bundle,ensure_ascii=False)+';\nconst PYTHON_SOURCE='+json.dumps(python,ensure_ascii=False)+';\nconst GPS_CSV='+json.dumps((P/'data/gps_raw.csv').read_bytes().decode('utf-8-sig'),ensure_ascii=False)+';'
    html=(source/'interface.html').read_text(encoding='utf-8')
    for marker,value in [('/*STYLE*/',(source/'style.css').read_text()),('/*DATA*/',json.dumps(run(speed,gap),ensure_ascii=False)),('/*APP*/',(source/'app.js').read_text()),('/*TRACE*/',(source/'trace.js').read_text()),('/*CODE*/',payload),('/*TRACE_UI*/',(source/'trace_ui.js').read_text()),('/*CASES*/',(source/'cases.js').read_text()),('/*CASE_CHARTS*/',(source/'case_charts.js').read_text()),('/*READING_GUIDE*/',(source/'reading_guide.js').read_text()),('/*CLASSROOM*/',(source/'classroom.js').read_text())]:
        html=html.replace(marker,value)
    (P/'开始演示.html').write_text(html,encoding='utf-8')
    print('Built v6 studio:',len(html),'characters')
if __name__=='__main__':build()
