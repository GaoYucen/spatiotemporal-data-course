"""Independent standard-library calculations for the v4 teaching examples."""
import math

def knn(query=1,k=2):
    donors=sorted([(abs(query-a),i,b) for i,(a,b) in enumerate([(0,10),(2,14),(6,40)],1)])
    return sum(r[2] for r in donors[:k])/k

def pca(angle=-45):
    points=[(2,0),(0,2),(3,1),(1,3)]
    w=(math.cos(math.radians(angle)), math.sin(math.radians(angle)))
    scores=[sum((q[j]-1.5)*w[j] for j in range(2)) for q in points]
    reconstructed=[tuple(1.5+z*v for v in w) for z in scores]
    return {'scores':scores,'reconstruction':reconstructed,'variance':sum(z*z for z in scores)/3,
            'error':sum((q[j]-r[j])**2 for q,r in zip(points,reconstructed) for j in range(2))}

def matching(cost=8):
    # Enumerate all paths independently of the browser's dynamic program.
    from itertools import product
    paths=[]
    for path in product(range(2),repeat=3):
        total=sum(2*j for j in path)+sum(0 if i==j==1 else cost for i,j in zip(path,path[1:]))
        paths.append((total,path))
    return min(paths)

def simplify(epsilon=.6):
    points=[(0,0),(1,.2),(2,2),(3,.2),(4,0)]
    def visit(a,b):
        if b-a<2:return [a,b]
        u,v=points[a],points[b];dx,dy=v[0]-u[0],v[1]-u[1]
        distances=[]
        for i in range(a+1,b):
            q=points[i];t=max(0,min(1,((q[0]-u[0])*dx+(q[1]-u[1])*dy)/(dx*dx+dy*dy)))
            distances.append((math.hypot(q[0]-u[0]-t*dx,q[1]-u[1]-t*dy),i))
        d,i=max(distances)
        return visit(a,i)[:-1]+visit(i,b) if d>epsilon else [a,b]
    return visit(0,len(points)-1)

def reference():
    return {'knn2':knn(),'knn3':knn(k=3),'pca':pca(),'matching':matching(),
            'simplify':{str(e):simplify(e) for e in [.5,.6,2.1]}}
if __name__=='__main__':
    import json
    print(json.dumps(reference(),ensure_ascii=False,indent=2))
