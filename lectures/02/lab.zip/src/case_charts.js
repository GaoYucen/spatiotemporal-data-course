const CASE_INFO={
  impute:['420条行程 · 分区缺失与极端值','全局均值和中位数填补可能抹掉分区差异。用预先遮盖的真实生成值计算误差。'],
  knn:['420条行程 · 双特征近邻','比较流量与距离的尺度。用同一批遮盖记录比较KNN和全局中位数。'],
  signal:['480个时刻 · 周期波动、尖峰与持续抬升','平滑与异常标记各自回答不同问题。标记阈值以首200时刻中的无注入尖峰残差为参考。'],
  scale:['420条流量记录 · 测试期分布上移','比较训练集拟合与包含测试数据的泄漏对照。测试期落在训练范围外是有效信息。'],
  pca:['420条行程 · 流量与用时','比较原尺度和标准化坐标下的第一主轴。解释方差与重构误差使用当前尺度。'],
  gps:['24台设备 · 重复、跳点与断流','按设备和时间排序，比较当前点与上一保留点。已注入跳点标签只用于事后核验。'],
  interpolate:['360个参考时刻 · 四种缺测长度','只在线性假设下补短缺口，长缺口保留为空。误差仅对本次补出的点计算。'],
  matching:['42个GPS观测 · 三条平行道路','同一路不加转移代价，在三个设定的连接时刻降低换路代价。比较逐点最近道路与整段最小代价。'],
  rdp:['360个采样点 · 弯道与扰动','同一轨迹上比较容差、保留点数和实测最大偏差。偏差按每个点所属的简化线段计算。'],
  aggregate:['24台设备 · 多格网、多时间窗','固定使用复杂GPS案例中12 m/s、120 s规则的保留点。同一设备可出现在多个格网。'],
};
function plotAxes(points,xName,yName,{equal=false}={}){
  const xs=points.map(q=>q[0]),ys=points.map(q=>q[1]);
  const xmin=Math.min(...xs),ymin=Math.min(...ys),xmax=Math.max(...xs),ymax=Math.max(...ys);
  const spanX=xmax-xmin||1,spanY=ymax-ymin||1;
  const sx=equal?Math.min(714/spanX,258/spanY):714/spanX;
  const sy=equal?sx:258/spanY;
  const left=81+(714-spanX*sx)/2, bottom=313-(258-spanY*sy)/2;
  const xy=([x,y])=>[left+(x-xmin)*sx,bottom-(y-ymin)*sy];
  let frame='';
  for(let i=0;i<=4;i++){
    const t=i/4,x=xmin+t*spanX,y=ymin+t*spanY,[cx,cy]=xy([x,y]);
    frame+=line(cx,bottom-spanY*sy,cx,bottom)+line(left,cy,left+spanX*sx,cy);
    frame+=text(cx-14,bottom+21,f(x,1),'tiny')+text(Math.max(5,left-48),cy+4,f(y,1),'tiny');
  }
  frame+=text(82,38,yName,'tiny')+text(665,357,xName,'tiny');
  return {xy,frame};
}
const series=(points,xy,color=C.a,width=3,dash='')=>`<polyline fill="none" stroke="${color}" stroke-width="${width}" stroke-dasharray="${dash}" points="${points.map(q=>xy(q).map(n=>n.toFixed(2)).join(',')).join(' ')}"/>`;
const smallDot=(xy,q,color,r=3,opacity=.65)=>{const [x,y]=xy(q);return `<circle cx="${x.toFixed(2)}" cy="${y.toFixed(2)}" r="${r}" fill="${color}" opacity="${opacity}"/>`};
const fmtRate=(n,d)=>f(100*n/d,1)+'%';
function complexPresentation(method,d,shown,p){
  let body='',metrics=[],calc='',rows=[],headers=[];
  if(method==='impute'||method==='knn'){
    const observed=d.reference.map(q=>[q.flow,q.length]),masked=d.masked.map(q=>[q.flow,q.length]);
    const pairs=d.masked.map((q,i)=>[q.time,d.estimates[i]]);
    const bounds=pairs.flat(),lo=Math.min(...bounds),hi=Math.max(...bounds);
    const chart=shown?plotAxes([[lo,lo],[hi,hi]],'遮盖前用时（分钟）','估计用时（分钟）',{equal:true}):plotAxes(observed.concat(masked),'流量（辆/时段）','路段长度（米）');
    const {xy,frame}=chart;
    body=frame+(shown?series([[lo,lo],[hi,hi]],xy,C.m,2,'5 5')+pairs.map(q=>smallDot(xy,q,C.a,4)).join(''):
      observed.map(q=>smallDot(xy,q,C.b)).join('')+masked.map(q=>smallDot(xy,q,C.o,4)).join(''));
    body+=text(80,20,shown?'绿点：各遮盖记录的估计　虚线：估计等于参考值':'蓝点：有效供体　橙点：待填补记录');
    metrics=[['样本 / 遮盖',`420 / ${d.masked.length}`],['当前 MAE',shown?`${f(d.error,3)} 分钟`:'待计算'],['中位数基线 MAE',shown?`${f(d.baselineError,3)} 分钟`:'待计算']];
    calc=shown?`在 ${d.masked.length} 条遮盖记录上取绝对误差的平均。参考用时只参与事后核验。首条记录估计 ${f(d.estimates[0])} 分钟，参考 ${f(d.masked[0].time)} 分钟。`:'估计使用未遮盖记录，观测中含极端用时。结果将显示估计与遮盖前用时的差异。';
    headers=['记录','分区','流量','长度','估计用时','参考用时',...(method==='knn'?['邻居ID']:[])];
    if(shown)rows=d.masked.map((q,i)=>[q.id,q.zone+1,f(q.flow),f(q.length),f(d.estimates[i]),f(q.time),...(method==='knn'?[d.neighbors[i].map(r=>r.id).join(', ')]:[])]);
  }else if(method==='signal'){
    const raw=d.signal.map(q=>[q.i,q.value]),{xy,frame}=plotAxes(raw,'时刻','观测值');
    body=frame+series(raw,xy,C.b,1.5);
    if(shown)body+=series(d.smoothed.map((y,i)=>[i,y]),xy,C.a,3)+d.flagged.map(i=>smallDot(xy,raw[i],C.r,4,1)).join('');
    body+=text(80,20,shown?'蓝：观测　绿：后向均值　红：残差异常候选':'观测序列含周期波动、短时尖峰和持续变化');
    metrics=[['时刻',d.signal.length],['标记候选',shown?d.flagged.length:'待计算'],['命中注入尖峰',shown?`${d.hits} / ${d.spikes}`:'待计算']];
    calc=shown?`当前观测减去上一时刻的后向均值，得到残差。用参考残差的 μ=${f(d.center)}、σ=${f(d.sigma)} 计算Z分数。另有 ${d.flagged.length-d.hits} 个标记与注入尖峰不重合。`:'关注两个不同现象：短尖峰和持续抬升。改变窗口，比较平滑滞后与候选标记。';
    headers=['时刻','观测','后向均值','残差','注入尖峰'];
    if(shown)rows=d.flagged.map(i=>[i,f(d.signal[i].value),f(d.smoothed[i]),f(d.residual[i]),d.signal[i].spike?'是':'否']);
  }else if(method==='scale'){
    const ys=shown?d.transformed:d.train.concat(d.test),pts=ys.map((y,i)=>[i,y]);
    const {xy,frame}=plotAxes(shown?pts.concat([[0,0],[0,1]]):pts,'记录序号',shown?'Min-Max 变换值':'流量');
    body=frame+pts.map((q,i)=>smallDot(xy,q,i<320?C.b:C.o,3)).join('');
    if(shown)body+=series([[0,1],[419,1]],xy,C.a,2,'6 5')+series([[0,0],[419,0]],xy,C.a,2,'6 5');
    body+=text(80,20,'蓝：训练期 320条　橙：测试期 100条'+(shown?'　虚线：拟合范围边界':''));
    metrics=[['训练 / 测试','320 / 100'],['拟合范围',shown?`${f(d.low,1)}–${f(d.high,1)}`:'待计算'],['测试越界',shown?`${d.outside} / 100`:'待计算']];
    calc=shown?`使用 a=${f(d.low)}、b=${f(d.high)}。测试首条 ${f(d.test[0])} → ${f(d.transformed[320])}。三分区使用三列独热编码。`:'最后100条存在分布上移。先确定哪些记录可以参与拟合。';
    headers=['测试记录','原流量','Min-Max值','分区编码'];
    if(shown)rows=d.test.map((v,i)=>[321+i,f(v),f(d.transformed[320+i]),d.categories[320+i].join(' / ')]);
  }else if(method==='pca'){
    const points=shown?d.centered:d.points;
    const {xy,frame}=plotAxes(shown?points.concat(d.reconstruction):points,shown?'中心化流量':'流量',shown?'中心化用时':'用时',{equal:shown});
    body=frame+points.map((q,i)=>smallDot(xy,q,[C.b,C.o,C.a][CASES.sensors[i].zone],3,.65)).join('');
    if(shown){
      const low=Math.min(...d.scores),high=Math.max(...d.scores);
      body+=series([d.w.map(v=>v*low),d.w.map(v=>v*high)],xy,C.m,2)+d.reconstruction.map(q=>smallDot(xy,q,C.ink??'var(--ink)',2.5,.4)).join('');
      for(let i=0;i<points.length;i+=21)body+=series([points[i],d.reconstruction[i]],xy,C.m,1,'4 3');
    }
    body+=text(80,20,shown?'彩色：三分区样本　浅点：一维重构　虚线：抽样残差':'三分区样本 · 流量与用时使用各自物理单位');
    metrics=[['样本 / 维度','420 / 2'],['保留方差',shown?fmtRate(d.ratio,1):'待计算'],['重构 SSE',shown?f(d.sse,2):'待计算']];
    calc=shown?`w = (${d.w.map(v=>f(v,3)).join(', ')})，方向 ${f(d.angle*180/Math.PI,1)}°。投影 z = Xc w，重构 z wᵀ。标准化前后的SSE对应不同尺度。`:'先看原变量的相关性和尺度。结果页可对比数据求出的第一主轴与手动方向。';
    headers=['记录','坐标（当前尺度）','投影','重构'];
    if(shown)rows=d.centered.map((q,i)=>[i+1,num(q),f(d.scores[i]),num(d.reconstruction[i])]);
  }else if(method==='gps'){
    const all=d.rows.map(q=>[q.x,q.y]),{xy,frame}=plotAxes(all,'局部 x（m）','局部 y（m）',{equal:true});
    body=frame;
    if(shown){
      const tracks=new Map();
      for(const q of d.kept){const key=q.device+'/'+q.segment;if(!tracks.has(key))tracks.set(key,[]);tracks.get(key).push([q.x,q.y])}
      body+=[...tracks.values()].map(q=>series(q,xy,C.a,1.7)).join('');
      body+=d.rejected.map(q=>smallDot(xy,[q.x,q.y],C.r,3.8,1)).join('');
    }else{
      body+=d.rows.map(q=>smallDot(xy,[q.x,q.y],C.b,1.6,.43)).join('');
    }
    body+=text(80,20,shown?'绿：保留轨迹，分段处断开　红：速度或时间约束拒绝':'24台设备的原始观测 · 重复点可能互相覆盖');
    metrics=[['输入点',d.rows.length],['重复 / 拒绝',shown?`${d.duplicates.length} / ${d.rejected.length}`:'待计算'],['保留点',shown?d.kept.length:'待计算']];
    const hits=d.rejected.filter(q=>q.status==='注入跳点').length,total=d.rows.filter(q=>q.status==='注入跳点').length;
    calc=shown?`速度阈值 ${p.speed} m/s，分段阈值 ${p.gap} s。识别 ${hits}/${total} 个注入跳点，另有 ${d.rejected.length-hits} 个拒绝点。其余轨迹保留原始米制坐标。`:'观察设备轨迹外的孤立点。速度规则对相邻观测关系敏感。';
    headers=['来源ID','设备','时间 s','速度 m/s','处理','注入标签'];
    if(shown)rows=[...d.rejected.map(q=>[q.id,q.device+1,q.t,f(q.velocity),'拒绝',q.status]),...d.duplicates.map(q=>[q.id,q.device+1,q.t,'—','重复',q.status])];
  }else if(method==='interpolate'){
    const asPoint=q=>[q.t,q.y],{xy,frame}=plotAxes(d.observed.map(asPoint),'时间（s）','局部 y（m）');
    body=frame;
    let segment=[];
    for(const q of d.observed){if(segment.length&&q.t-segment.at(-1)[0]>10){body+=series(segment,xy,C.b,2);segment=[]}segment.push(asPoint(q))}
    body+=series(segment,xy,C.b,2);
    for(const g of d.gaps){
      const a=xy(asPoint(g.start)),b=xy(asPoint(g.end));
      body+=line(a[0],306,b[0],306,shown&&g.split?C.r:C.o,'5 4',4)+text((a[0]+b[0])/2-12,288,`${g.interval}s`,'tiny');
      if(shown&&!g.split)body+=series([asPoint(g.start),asPoint(g.end)],xy,C.o,3,'5 4');
    }
    body+=text(80,20,shown?'蓝：观测　橙虚线：估计　红：保留缺口':'四个缺口 · 标注两端观测时间差');
    metrics=[['观测 / 缺口',`${d.observed.length} / ${d.gaps.length}`],['补出 / 留空',shown?`${d.estimates.length} / ${d.unknown}`:'待计算'],['补出点 RMSE',shown&&d.rmse!==null?`${f(d.rmse,2)} m`:'—']];
    calc=shown?`端点时间差 ≤ ${p.gap} s 的缺口允许插值。RMSE按补出的点计算，改变阈值也会改变误差的评价样本。`:'四个时间差各不相同。比较阈值改变时的覆盖范围与误差。';
    headers=['起点 s','终点 s','间隔 s','操作'];
    if(shown)rows=d.gaps.map(q=>[q.start.t,q.end.t,q.interval,q.split?'保留缺口':'线性插值']);
  }else if(method==='matching'){
    const pts=d.matching.map(q=>[q.x,q.y]),{xy,frame}=plotAxes(pts.concat(d.roadY.map(y=>[40,y])),'局部 x（m）','局部 y（m）');
    body=frame+d.roadY.map(y=>series([[40,y],[778,y]],xy,C.m,1.5,'5 5')).join('')+pts.map(q=>smallDot(xy,q,C.b,3)).join('');
    if(shown)body+=series(d.nearest.map((j,i)=>[d.matching[i].x,d.roadY[j]]),xy,C.o,2,'6 5')+series(d.path.map((j,i)=>[d.matching[i].x,d.roadY[j]]),xy,C.a,3);
    body+=text(80,20,shown?'蓝点：GPS　橙虚线：逐点最近　绿实线：动态规划':'三条候选道路 · 蓝点为含横向噪声的GPS');
    metrics=[['观测 × 候选','42 × 3'],['总代价 最近 / DP',shown?`${f(d.nearestCost,1)} / ${f(d.cost,1)}`:'待计算'],['命中参考道路 最近 / DP',shown?`${d.nearestCorrect} / ${d.correct}`:'待计算']];
    calc=shown?`观测代价为 (横向偏差/22)²。非连接时刻换路代价为 ${p.transition}，连接时刻为其0.3倍。两条路径按同一代价计算。`:'本例用三条平行路和简化转移代价；参考道路标签用于核验路径，未参与推断。';
    headers=['时刻','GPS y','最近道路','DP道路','参考道路','DP各路累计代价'];
    if(shown)rows=d.matching.map((q,i)=>[i+1,f(q.y),d.nearest[i]+1,d.path[i]+1,q.truth+1,num(d.values[i])]);
  }else if(method==='rdp'){
    const {xy,frame}=plotAxes(d.points,'局部 x（m）','局部 y（m）',{equal:true});
    body=frame+series(d.points,xy,C.b,shown?1.2:2);
    if(shown)body+=series(d.keep.map(i=>d.points[i]),xy,C.a,3)+d.keep.map(i=>smallDot(xy,d.points[i],C.a,4,1)).join('');
    body+=text(80,20,shown?'蓝：原始轨迹　绿：简化线与保留顶点':'原轨迹含多处弯道和小幅扰动 · 等比例坐标');
    metrics=[['原点数',d.points.length],['保留点 / 压缩率',shown?`${d.keep.length} / ${fmtRate(d.points.length-d.keep.length,d.points.length)}`:'待计算'],['最大偏差',shown?`${f(d.maxError,2)} m`:'待计算']];
    calc=shown?`逐段核对原点到简化线段的距离，最大为 ${f(d.maxError,3)} m，容差 ε=${p.epsilon} m。`:'弯道与噪声对容差敏感。调大容差比较采样压缩与几何误差。';
    headers=['保留点','x（m）','y（m）'];
    if(shown)rows=d.keep.map(i=>[i+1,...d.points[i].map(v=>f(v))]);
  }else{
    const window=Math.min(p.timeSlot,d.maxTime),groups=d.groups.filter(q=>q.t===window);
    const pts=d.rows.map(q=>[q.x,q.y]);
    const bounds=shown?pts.concat(groups.flatMap(q=>[[q.x*p.cell,q.y*p.cell],[(q.x+1)*p.cell,(q.y+1)*p.cell]])):pts;
    const {xy,frame}=plotAxes(bounds,'局部 x（m）','局部 y（m）',{equal:true});
    body=frame;
    if(shown){
      const max=Math.max(1,...groups.map(q=>q[p.count]));
      for(const q of groups){
        const [x,y]=xy([q.x*p.cell,(q.y+1)*p.cell]),[right,bottom]=xy([(q.x+1)*p.cell,q.y*p.cell]);
        body+=rect(x+1,y+1,Math.max(1,right-x-2),Math.max(1,bottom-y-2),C.a,.15+.8*q[p.count]/max);
        if(right-x>25)body+=text(x+5,y+16,q[p.count],'tiny','var(--ink)');
      }
    }else body+=pts.map(q=>smallDot(xy,q,C.b,1.6,.45)).join('');
    body+=text(80,20,shown?`第 ${window+1} 窗 · 色深与格内数字表示${p.count==='points'?'点数':'设备数'}`:'清洗后轨迹点 · 所有时间窗');
    metrics=[['全部保留点',d.rows.length],['格网 × 时间组',shown?d.groups.length:'待计算'],['当前窗点数',shown?groups.reduce((s,q)=>s+q.points,0):'待计算']];
    calc=shown?`时间窗 [${window*p.window}, ${(window+1)*p.window}) s。格网边长 ${p.cell} m，同格同窗内设备去重。`:'缩放格网或时间窗口，观察密度和设备计数随分辨率变化。';
    headers=['格网x','格网y','轨迹点数','去重设备数'];
    if(shown)rows=groups.map(q=>[q.x,q.y,q.points,q.devices]);
  }
  return {body,metrics,calc,rows,headers};
}
