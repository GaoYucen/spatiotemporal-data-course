/* Reading cues connect the classroom graphics to their underlying calculations. */
const SIMPLE_READING={
  impute:'横轴是记录编号，柱高是数值。前四柱是观测，第五柱是缺失项。切换均值和中位数，比较极端值100对两种填补的影响。',
  knn:'横向位置代表A值，靠查询点越近的供体越优先。供体的B值在选完邻居后才用来求平均，因此B=40的记录即使数值醒目，也要先看它离查询点多远。',
  signal:'从左到右是时间，灰线是观测，绿线是后向均值。峰值在平均时被附近较低的值稀释。图下的Z分数是独立小算例。',
  scale:'上下两条数轴分别显示变换前后的值，连线把同一条记录的两个位置连起来。看橙色测试点是否落在训练区间的右侧。',
  pca:'左图保留样本原来的二维坐标，重构点在选定轴上。虚线连接原样本与重构位置。右侧只保留沿这根轴的一个分数，多个样本可以得到同一分数。',
  gps:'横纵轴是米制位置。处理结果中，连续保留点按设备与段号连线，红点表示规则拒绝，空心圈表示重复位置。颜色表示处理决定。',
  interpolate:'两端蓝点是已有观测。橙点是按时间比例在端点间求得的位置；即使展示这个估计，分段规则仍可把长间隔保留为未知。',
  matching:'从左到右是三个观测时刻，每列A/B是该时刻的候选状态。圆内是到该状态为止的累计最小代价，绿线是从末列向前回溯得到的整段选择。',
  rdp:'灰线经过所有原点，绿线仅连接保留点。重点看被删点到对应绿线段的偏差是否超过容差。',
  aggregate:'每根柱代表一个空间格网与时间窗的组合。点数是该组记录数，设备数按组去重，两个数回答的是不同问题。',
};
const COMPLEX_READING={
  impute:[
    '输入图横轴是流量，纵轴是路段长度。每点一条行程，橙点的用时已被遮盖，坐标仍可用于观察遮盖是否集中。',
    '结果图改用同一单位比较用时。横轴是遮盖前的参考用时，纵轴是估计。虚线表示完全一致。全局填补给所有记录同一个估计，点自然排成一条水平线。',
  ],
  knn:[
    '输入图用流量和路段长度显示可用于找邻居的两列。橙点缺少用时，蓝点有可用于填补的用时。标准化影响距离计算，图上的输入仍按原单位显示。',
    '结果图每点对应一条被遮盖行程。横轴是预留的参考用时，纵轴是估计。点越贴近等值虚线，该条记录的估计误差越小。它与输入图是同一批记录的两种坐标。',
  ],
  signal:[
    '横轴是时刻，纵轴是观测值。短尖峰迅速回落，约255时刻的持续抬升会延续。把两种变化放在一起，才能看到平滑和阈值的局限。',
    '绿线显示窗口平均，红点标记相对上一时刻平滑值的较大偏离。持续抬升刚开始时也可能出现红点，等窗口适应新水平后偏离会缩小。',
  ],
  scale:[
    '按记录顺序画流量，蓝点是训练期，橙点是刻意上移的测试期。这样可以先看到两个时期的取值范围。',
    '保留记录顺序，把纵轴改成缩放值。虚线0和1对应拟合集的最小值和最大值。训练期拟合时，超过训练极值的测试点会落在虚线外。',
  ],
  pca:[
    '横轴为流量，纵轴为用时，每点一条行程，颜色区分三个分区。散点斜着展开，说明两个变量共同变化。',
    '结果图使用当前处理尺度。白色轴是降维方向，浅点是投影后在二维图上的重构。短虚线是部分样本丢掉的那一截。保留方差衡量点云沿所选方向展开的比例。',
  ],
  gps:[
    '每点是一个GPS观测。原始图只画散点，因为直接连线容易把跳点和断流误画成行驶路径。精确重复点会重叠。',
    '绿线只连接同一设备同一段里的保留点。红点是速度规则拒绝的观测。重复点单独计数，断流较长时即使后续点通过速度约束也会另起一段。',
  ],
  interpolate:[
    '图上只画随时间变化的y坐标，计算同时处理x和y。缺口两端有观测，中间空白表示被遮盖的时刻。',
    '橙虚线是允许补齐的缺口。超过阈值的缺口保持断开。改变阈值会同时改变补齐覆盖率和参加误差统计的样本。',
  ],
  matching:[
    '蓝点是含定位噪声的观测，三条水平虚线是候选道路。某个点可能偶然更靠近另一条路，单看横向距离无法知道车辆是否换路。',
    '两条路径从左到右对应同一串观测。橙虚线每次就近选择，可能来回跳路。绿线比较整段总代价。图中斜线表示前后时刻的候选变化，计算根据是否处在连接时刻计入不同的换路代价。',
  ],
  rdp:[
    '这是等比例平面轨迹。蓝线保留所有采样点，弯道决定大尺度形状，小波动用来观察容差对保留点数的影响。',
    '绿线是简化结果。蓝绿贴近说明几何形状近似。最大偏差按原点到所属简化线段计算，压缩率表示删掉的点占原点数的比例。',
  ],
  aggregate:[
    '散点来自复杂GPS案例的清洗保留点，包含所有时间窗。单看点的密度无法区分设备更多，还是同一设备上报更频繁。',
    '热图只显示选中的时间窗。每格的颜色深浅对应当前统计量，数字可用来精确比较。色深随当前窗重设，跨窗时应读数字。',
  ],
};

function workedExample(method,d,p){
  if(method==='impute'||method==='knn'){
    const q=d.masked[0],estimate=d.estimates[0],error=Math.abs(estimate-q.time);
    const source=method==='knn'
      ?`用流量和路段长度找 ${d.neighbors[0].length} 个邻居。邻居用时为 ${d.neighbors[0].slice(0,7).map(r=>f(r.time)).join('、')}${d.neighbors[0].length>7?' 等':''} 分钟，平均后得到 ${f(estimate)} 分钟。`
      :`对 ${d.reference.length} 条有效用时取${p.method==='mean'?'均值':'中位数'}，统一填入 ${f(estimate)} 分钟。`;
    return `看记录 #${q.id}。${source} 揭开参考值 ${f(q.time)} 分钟后，本条绝对误差为 ${f(error)} 分钟。把 ${d.masked.length} 条误差平均，得到 ${f(d.error)} 分钟。中位数基线在同一批记录上得到 ${f(d.baselineError)} 分钟。`;
  }
  if(method==='signal'){
    const i=255,r=d.residual[i],z=(r-d.center)/d.sigma;
    return `持续抬升起点 t=${i}。观测 ${f(d.signal[i].value)} 减上一时刻平滑值 ${f(d.smoothed[i-1])}，残差约 ${f(r)}，标准化后 Z≈${f(z)}。${d.flagged.includes(i)?'该点超阈值，被标红。':'当前阈值下该点未标红。'} 全段 ${d.flagged.length} 个候选中，${d.hits} 个与注入尖峰重合。`;
  }
  if(method==='scale'){
    return `首条测试记录为 ${f(d.test[0])}。代入拟合区间，(${f(d.test[0])}−${f(d.low)})÷(${f(d.high)}−${f(d.low)})≈${f(d.transformed[320])}。当前有 ${d.outside} 条测试记录落在 [0,1] 外。若把测试记录也拿来决定极值，越界数会降为0，这是拟合范围被改变的结果。`;
  }
  if(method==='pca'){
    const percent=f(100*d.ratio,1);
    return `第一条记录处理后的坐标是 (${d.centered[0].map(v=>f(v)).join(', ')})。沿当前轴只保存投影分数 ${f(d.scores[0])}，用它重构为 (${d.reconstruction[0].map(v=>f(v)).join(', ')})。全部 ${d.points.length} 条记录沿该方向保留 ${percent}% 方差，剩余偏差汇总为 SSE ${f(d.sse)}。`;
  }
  if(method==='gps'){
    const q=d.rejected.find(r=>r.velocity!==null);
    const previous=q&&d.kept.filter(r=>r.device===q.device&&r.t<q.t).at(-1);
    const point=previous?`看 #${q.id}。距同设备上一保留点 #${previous.id} 约 ${f(Math.hypot(q.x-previous.x,q.y-previous.y))} 米，间隔 ${q.t-previous.t} 秒，速度约 ${f(q.velocity)} m/s，高于 ${p.speed} m/s，故标红。`:'当前可见的拒绝点没有可展示的有限速度算例。';
    return `${point} 总数核对为 ${d.rows.length} = ${d.kept.length} 保留 + ${d.rejected.length} 拒绝 + ${d.duplicates.length} 重复。`;
  }
  if(method==='interpolate'){
    const g=d.gaps.find(g=>!g.split)||d.gaps[0],sample=d.estimates.find(q=>q.t>g.start.t&&q.t<g.end.t);
    const demo=sample?`缺口两端间隔 ${g.interval} 秒。首个待补时刻距起点 ${sample.t-g.start.t} 秒，时间比例约 ${f((sample.t-g.start.t)/g.interval,3)}，得到 y≈${f(sample.y)} 米。`:`首个缺口间隔 ${g.interval} 秒，超过阈值 ${p.gap} 秒，保留空白。`;
    return `${demo} 这次补出 ${d.estimates.length} 个位置，仍留空 ${d.unknown} 个。RMSE 汇总的是已补出点与参考位置之间的距离误差。`;
  }
  if(method==='matching'){
    const i=d.example?.index??-1;
    const point=i>=0?`第 ${i+1} 个观测的 y≈${f(d.matching[i].y)} 米。逐点最近选道路 ${d.nearest[i]+1}，整段推断选道路 ${d.path[i]+1}。若只把这一点改选最近道路，定位代价少 ${f(d.example.emissionSaving)}，但计入前后换路后，总代价增加 ${f(d.example.extraTotal)}。`:'当前参数下，两种方法的道路选择一致。';
    return `${point} 两条序列按同一规则累加定位偏差与换路代价，分别为 ${f(d.nearestCost)} 和 ${f(d.cost)}。按生成数据时保留的道路标签核对，分别命中 ${d.nearestCorrect} 和 ${d.correct} 个观测。`;
  }
  if(method==='rdp'){
    return `容差 ${p.epsilon} 米时，${d.points.length} 个点保留 ${d.keep.length} 个。删点比例为 (${d.points.length}−${d.keep.length})÷${d.points.length}≈${fmtRate(d.points.length-d.keep.length,d.points.length)}。逐段复核的最大偏差约 ${f(d.maxError)} 米，未超过容差。`;
  }
  const window=Math.min(p.timeSlot,d.maxTime),groups=d.groups.filter(q=>q.t===window);
  const g=groups.reduce((best,q)=>!best||q.points-q.devices>best.points-best.devices?q:best,null);
  if(!g)return '当前时间窗没有保留点。可切换时间窗查看有数据的格网。';
  return `看第 ${window+1} 个时间窗的格网 (${g.x}, ${g.y})。它收到 ${g.points} 条记录，来自 ${g.devices} 台不同设备。切换统计量后，同一个格子的数字会在这两个值之间切换。`;
}
