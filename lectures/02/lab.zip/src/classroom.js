const CASE_DEFAULTS={
  impute:{method:'median'},knn:{k:7,units:'scaled'},signal:{window:9,z:3},
  scale:{leak:'train'},pca:{units:'scaled',direction:'axis',angle:0},
  gps:{speed:DATA.speed,gap:DATA.gap},interpolate:{gap:150},
  matching:{transition:8},rdp:{epsilon:8},aggregate:{cell:250,window:180,count:'points',timeSlot:0},
};
const CASE_THEORY={
  impute:['均值 / 中位数由有效供体估计。','x̂ = mean(X<sub>obs</sub>) 或 median(X<sub>obs</sub>)','比较全局统计量对有分区缺失和极端值的数据的影响。'],
  knn:['使用流量与路段长度在有效记录中搜索K个近邻。','d(q,r) = √Σ<sub>j</sub>[(q<sub>j</sub>−r<sub>j</sub>)/σ<sub>j</sub>]²<br>x̂ = Σ<sub>r∈N</sub> x<sub>r</sub> / K','σ来自未遮盖供体；原始单位模式将σ设为1。K和值域会改变邻居。'],
  signal:['后向均值使用当前及之前的观测。异常判断使用当前值对上一时刻平滑值的残差。','m<sub>t</sub> = mean(x<sub>t−w+1:t</sub>)<br>r<sub>t</sub> = x<sub>t</sub> − m<sub>t−1</sub><br>|r<sub>t</sub>−μ| / σ &gt; τ','起始窗口使用已有值。参考残差用无注入尖峰的前200时刻校准。'],
  scale:['缩放极值由所选拟合集确定。类别按三个分区做独热表示。','x′ = (x−min<sub>fit</sub>)/(max<sub>fit</sub>−min<sub>fit</sub>)','测试期上移。允许变换结果超出[0,1]；泄漏对照用全部记录拟合。'],
  pca:['对中心化或标准化后的二维数据求协方差，比较一维重构。','S = X<sub>c</sub>ᵀ X<sub>c</sub>/(n−1)<br>z = X<sub>c</sub>w，X̂<sub>c</sub> = zwᵀ','第一主轴由当前数据求得。手动方向用于比较；误差和占比在当前尺度上解释。'],
  gps:['以对象、时间、坐标去重，使用同设备上一保留点进行速度约束和分段。','v = ‖s<sub>t</sub>−s<sub>prev</sub>‖₂ / Δt<br>Δt &gt; G → 新段','位置使用局部米制坐标；跳点标签只用于事后核验。'],
  interpolate:['在允许补齐的短缺口里，以固定10秒间隔估计坐标。','α = (t−t<sub>a</sub>)/(t<sub>b</sub>−t<sub>a</sub>)<br>ŝ = (1−α)s<sub>a</sub> + αs<sub>b</sub>','时间差超过阈值时保留缺口。误差仅覆盖已补出的点，参考轨迹为合成真值。'],
  matching:['在每一时刻的三个候选道路中，找观测和转移总代价最低的整段序列。','V<sub>t</sub>(j) = E<sub>t</sub>(j) + min<sub>i</sub>[V<sub>t−1</sub>(i)+C<sub>t</sub>(i,j)]','平行道路和连接时刻为教学设定，转移是代价规则。'],
  rdp:['递归寻找离当前端点线段最远的中间点。超出容差时保留该点并分裂。','d<sub>max</sub> = max<sub>i</sub> d(p<sub>i</sub>,[p<sub>a</sub>,p<sub>b</sub>])<br>d<sub>max</sub> &gt; ε → 分裂','等比例空间坐标。几何容差不约束速度与停留语义。'],
  aggregate:['按空间格网和左闭右开时间窗分组。','g = (⌊x/L⌋, ⌊y/L⌋, ⌊t/W⌋)<br>设备数 = |{设备 ID : 记录 ∈ g}|','色深按当前时间窗归一化。设备在同格同窗去重。'],
};
let classroomCase='simple',detailMode=false,classroomPhase=0;
let cachedKey='',cachedCase;
const basePaint=paint,baseSelect=selectLab,baseSetParam=setParam,baseControls=controls;
const baseAdvance=advance,baseGoStep=goStep,basePlay=play,baseReset=reset;
function selectedDefaults(i){
  return classroomCase==='complex'&&!detailMode?CASE_DEFAULTS[TRACE_METHODS[i]]:LABS[i].defaults;
}
function getComplex(){
  const method=TRACE_METHODS[active],key=JSON.stringify([method,p]);
  if(key!==cachedKey){cachedCase=complexCase(method,p);cachedKey=key}
  return cachedCase;
}
controls=function(){
  if(classroomCase==='simple'||detailMode){baseControls();return}
  const units=()=>choose('units','特征尺度',[['scaled','标准化'],['raw','原始单位']]);
  const perCase={
    impute:()=>baseControls(),
    knn:()=>range('k','邻居数量 K',1,31,1)+units(),
    signal:()=>range('window','后向窗口',2,40,1)+range('z','异常阈值 τ',1,6,.1),
    scale:()=>baseControls(),
    pca:()=>units()+choose('direction','投影方向',[['axis','数据第一主轴'],['manual','手动比较']])+
      (p.direction==='manual'?range('angle','方向 θ（度）',-90,90,1):''),
    gps:()=>baseControls(),
    interpolate:()=>range('gap','允许插值的最大端点间隔 s',60,480,10),
    matching:()=>range('transition','非连接处换路代价',0,20,1),
    rdp:()=>range('epsilon','几何容差 ε / m',.5,30,.5),
    aggregate:()=>range('cell','格网边长 m',50,500,50)+range('window','时间窗口 s',60,600,60)+
      choose('count','统计对象',[['points','轨迹点'],['devices','去重设备']])+
      range('timeSlot','时间窗编号（从0起）',0,getComplex().maxTime,1),
  };
  const html=perCase[TRACE_METHODS[active]]();
  if(html!==undefined)$('controls').innerHTML=html;
};
function simplePresentation(method,trace,shown){
  const e=trace.events[shown?trace.events.length-1:0],a=accumulated(shown?trace.events:[e]);
  const outputs={
    impute:()=>['填补值',num(trace.result.estimate)],
    knn:()=>['邻居填补估计',num(trace.result.estimate)],
    signal:()=>['尖峰处平滑值',num(trace.result.smoothed[5])],
    scale:()=>['测试 Min-Max',num(trace.result.scaled.at(-1))],
    pca:()=>['方差保留',fmtRate(trace.result.ratio,1)],
    gps:()=>['保留 / 拒绝 / 重复',[trace.result.kept.length,trace.result.rejected.length,trace.result.duplicates.length].join(' / ')],
    interpolate:()=>['估计坐标',num(trace.result.estimate)],
    matching:()=>['最优路径 / 代价',trace.result.path.map(i=>i?'B':'A').join('')+' / '+trace.result.cost],
    rdp:()=>['保留点数',trace.result.keep.length],
    aggregate:()=>['格网 × 时间组',trace.result.groups.length],
  };
  return {body:plotTrace(method,e,a),metrics:[['数据','课件算例'],shown?outputs[method]():['结果','待展示']],
    calc:explanation(method,e,a),table:shown?stateTable(method,e,a):'',data:shown?trace.result:e.state};
}
function paintClassroom(){
  const lab=LABS[active],method=TRACE_METHODS[active],complex=classroomCase==='complex',shown=classroomPhase===1;
  let graph;
  if(complex){
    const data=getComplex();
    graph=complexPresentation(method,data,shown,p);
    if(shown)graph.calc=workedExample(method,data,p);
    graph.data=shown?data:{seed:20261106,scenario:CASE_INFO[method][0]};
    graph.table=shown&&graph.rows.length?traceTable(graph.headers,graph.rows.slice(0,160).map(row=>row.map(esc))):'';
    if(graph.rows.length>160)graph.table+='<p class="hint">表格显示前160条。导出可查看完整计算结果。</p>';
  }else graph=simplePresentation(method,traceData(),shown);
  $('stage').innerHTML=svg(graph.body);
  $('metrics').innerHTML=graph.metrics.map(([k,v])=>`<div class="metric"><small>${esc(k)}</small><strong>${esc(v)}</strong></div>`).join('');
  $('case-note').textContent=complex?CASE_INFO[method][0]+'。'+CASE_INFO[method][1]:'使用课件中的小样本验证方法。切换复杂实例可观察同一方法在更大样本或更复杂条件下的结果。';
  $('reading-label').hidden=false;
  $('reading-guide').hidden=false;
  $('reading-guide').textContent=complex?COMPLEX_READING[method][Number(shown)]:SIMPLE_READING[method];
  $('calculation').textContent=graph.calc;
  $('explanation').textContent=shown?'调整参数可直接比较处理结果，展开下方表格可查看记录。':'先观察数据，选定参数，再展示处理结果。';
  $('stepTitle').textContent=shown?'处理结果':'观察输入';
  $('stepNum').textContent=shown?'02':'01';
  $('stepLabel').textContent=shown?'2 / 2':'1 / 2';
  $('show-input').setAttribute('aria-pressed',String(!shown));
  $('show-result').setAttribute('aria-pressed',String(shown));
  $('case-simple').setAttribute('aria-pressed',String(!complex));
  $('case-complex').setAttribute('aria-pressed',String(complex));
  $('trace-panel').hidden=true;
  $('case-results').hidden=!graph.table;
  $('case-table').innerHTML=graph.table;
  const theory=complex?CASE_THEORY[method]:[lab.definition,lab.formula,lab.boundary];
  $('definition').textContent=theory[0];
  $('formula').innerHTML=theory[1];
  $('symbols').textContent=complex?'详见当前演算和结果表。':lab.symbols;
  $('boundary').textContent=theory[2];
  result={lab:lab.short,method,case:classroomCase,parameters:{...p},phase:shown?'result':'input',
    ...(complex?{seed:20261106}:{}),[shown?'result':'input']:graph.data};
  $('data').textContent=JSON.stringify(result,null,2);
}
paint=function(){if(detailMode)basePaint();else paintClassroom()};
selectLab=function(i){classroomPhase=0;baseSelect(i)};
setParam=function(key,value){
  if(detailMode){baseSetParam(key,value);return}
  p[key]=typeof p[key]==='number'?Number(value):value;
  if(classroomCase==='complex'&&TRACE_METHODS[active]==='aggregate'&&key==='window')p.timeSlot=Math.min(p.timeSlot,getComplex().maxTime);
  if(key==='direction'||(TRACE_METHODS[active]==='aggregate'&&key==='window'))controls();
  else if($('out-'+key))$('out-'+key).textContent=p[key];
  paint();
};
goStep=function(i){if(detailMode)baseGoStep(i);else showPhase(i)};
advance=function(d){if(detailMode)baseAdvance(d);else showPhase(classroomPhase+d)};
play=function(){if(detailMode)basePlay();else showPhase(1-classroomPhase)};
reset=function(){if(detailMode){baseReset();return}classroomPhase=0;p={...selectedDefaults(active)};controls();paint()};
function showPhase(i){classroomPhase=Math.max(0,Math.min(1,i));paint()}
function setCase(which){
  if(detailMode||which===classroomCase)return;
  classroomCase=which;
  p={...selectedDefaults(active)};
  controls();
  paint();
}
function toggleDetails(){
  stop();
  detailMode=!detailMode;
  classroomCase='simple';
  classroomPhase=0;
  document.body.classList.toggle('classroom',!detailMode);
  $('case-results').hidden=true;
  $('reading-label').hidden=detailMode;
  $('reading-guide').hidden=detailMode;
  processView=detailMode;
  arrangeTrace();
  $('view-mode').textContent=detailMode?'返回课堂演示':'展开简单用例逐步演算';
  baseSelect(active);
}
processView=false;
document.body.classList.add('classroom');
arrangeTrace();
window.classroomDefaults=selectedDefaults;
$('view-mode').textContent='展开简单用例逐步演算';
selectLab(0);
