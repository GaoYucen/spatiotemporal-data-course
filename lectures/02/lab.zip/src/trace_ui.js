'use strict';
const TRACE_METHODS={0:'impute',1:'knn',2:'signal',3:'scale',4:'pca',5:'gps',6:'interpolate',7:'matching',8:'rdp',9:'aggregate'};
const TRACE_TITLES={statistics:'计算均值与中位数',window:'取后向窗口',average:'计算窗口均值',zscore:'计算Z分数',fit:'拟合缩放参数',transform:'变换一个样本',standardize:'计算标准化参数',encode:'编码一个类别',interval:'计算时间间隔',weight:'确定时间权重',coordinate:'计算一个坐标',assign:'确定格网与时间窗',increment:'更新计数与设备集合',input:'读取输入',distance:'逐项计算距离',sort:'排序',select:'选择有效供体',sum:'累加供体属性',result:'核对最终结果',mean:'计算列均值',center:'中心化一个样本',outer:'累加一个外积',covariance:'除以 n−1 得到协方差',eigen:'求二维特征值',axis:'归一化第一主轴',direction:'设置比较方向',project:'投影一个样本',reconstruct:'重构与累加残差',initialize:'初始化第一列',candidate:'计算一个前驱候选',update:'选择最小值并保存前驱',terminal:'选择终点',backtrack:'回溯一步',enter:'进入递归区间',leaf:'相邻端点，结束递归',decision:'比较阈值并决策',return:'返回父区间',duplicate:'检查一条重复键',speed:'计算与上一保留点的速度'};
const esc=v=>String(v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const num=v=>v===null||v===undefined?'—':typeof v==='number'?f(v,4):Array.isArray(v)?'['+v.map(num).join(', ')+']':esc(v);
let traceCache=null,traceKey='',predicting=false,compareSnapshot=null;
function traceData(){const method=TRACE_METHODS[active],key=JSON.stringify([method,p]);if(key!==traceKey){traceKey=key;traceCache=computeTrace(method,p,DATA.raw)}return traceCache}
function detailTitle(e){const s=e.state;return (TRACE_TITLES[e.action]||e.action)+(s.id!==undefined?` · ${['pca','impute','signal','scale'].includes(TRACE_METHODS[active])?'样本 '+(s.id+1):TRACE_METHODS[active]==='interpolate'?(s.id===0?'x坐标':'y坐标'):'#'+s.id}`:'')+(s.t!==undefined?` · t=${s.t+1}${s.j!==undefined?' / '+(s.j?'B':'A'):''}`:'')+(s.a!==undefined?` · [p${s.a},p${s.b}]`:'')}
function traceTable(headers,rows,highlight=-1){return `<div class="table-scroll"><table class="trace-table"><thead><tr>${headers.map(x=>`<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${rows.map((row,i)=>`<tr class="${i===highlight?'current-row':''}">${row.map(x=>`<td>${x}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`}
function accumulated(events){const a={distances:{},chosen:[],scores:{},centered:{},rec:{},values:[[null,null],[null,null],[null,null]],back:[[null,null],[null,null],[null,null]],keep:[0,4],gps:{},gpsOrder:[],tree:[],path:{},basic:{},rows:{},windows:{},groups:{}};
 for(const e of events){let s=e.state;a.basic[e.action]=s;if(['sum','average','transform','coordinate'].includes(e.action))a.rows[s.id]=s;if(e.action==='window')a.windows[s.id]=s.values;if(e.action==='increment')a.groups[s.key]=s;switch(e.action){case'distance':a.distances[s.id]=s.distance;break;case'select':a.chosen=s.ids;break;case'center':a.centered[s.id]=s.centered;break;case'project':a.scores[s.id]=s.score;break;case'reconstruct':a.rec[s.id]=s.point;break;case'initialize':a.values[0]=s.values;break;case'update':a.values[s.t][s.j]=s.value;a.back[s.t][s.j]=s.previous;break;case'terminal':a.path[2]=s.end;break;case'backtrack':a.path[s.t]=s.state;break;case'enter':a.tree.push({a:s.a,b:s.b,depth:s.depth,status:'审查中'});break;case'decision':if(s.a!==undefined){let node=[...a.tree].reverse().find(n=>n.a===s.a&&n.b===s.b);if(node)node.status=s.split?'分裂 p'+s.id:'不分裂';if(s.split)a.keep.push(s.id)}else if(s.id!==undefined){a.gps[s.id]={...a.gps[s.id],...s,status:s.accepted?'保留':'拒绝'}}break;case'leaf':{let node=[...a.tree].reverse().find(n=>n.a===s.a&&n.b===s.b);if(node)node.status='相邻端点';break}case'duplicate':if(!a.gpsOrder.includes(s.id))a.gpsOrder.push(s.id);a.gps[s.id]={...s,status:s.duplicate?'重复':'待计算'};break;case'speed':a.gps[s.id]={...a.gps[s.id],...s};break;case'result':if(s.keep)a.keep=s.keep;break}}
 a.keep=[...new Set(a.keep)].sort((a,b)=>a-b);return a;
}
function explanation(method,e,a){const s=e.state;if(['impute','signal','scale','interpolate','aggregate'].includes(method))return basicExplanation(method,e,a);
 if(method==='knn'){
  const donor=[[1,0,10],[2,2,14],[3,6,40]].find(r=>r[0]===s.id);
  if(e.action==='distance')return `d(q,r${s.id}) = |${num(p.query)} − ${donor[1]}| = ${num(s.distance)}。B列缺失，不参与距离。`;
  if(e.action==='sort')return `按 (距离, ID) 排序：${s.order.map(i=>'r'+i).join(' → ')}；等距时选编号较小者。`;
  if(e.action==='select')return `N_K = {${s.ids.map(i=>'r'+i).join(', ')}}。本例全部供体的B有效。`;
  if(e.action==='sum')return `加入 r${s.id} 的 B=${donor[2]}；累计 B 总和 = ${num(s.total)}。`;
  if(e.action==='result')return `B̂ = ΣB / K = ${num(s.estimate*p.k)} / ${p.k} = ${num(s.estimate)}。这是估计值。`;
  return `查询 A=${num(p.query)}，B=?；K=${p.k}。逐个算距离后才允许选邻居。`;
 }
 if(method==='matching'){
  if(e.action==='candidate'){let prior=a.values[s.t-1][s.i],c=s.i===1&&s.j===1?0:p.transition;return `前驱 ${s.i?'B':'A'} → ${s.j?'B':'A'}：V${s.t}(${s.i?'B':'A'}) + C = ${num(prior)} + ${c} = ${num(s.candidate)}。尚未加当前观测代价。`}
  if(e.action==='update'){const candidates=a.values[s.t-1].map((v,i)=>v+(i===1&&s.j===1?0:p.transition));return `V${s.t+1}(${s.j?'B':'A'}) = ${s.j?2:0} + min(${candidates.map(num).join(', ')}) = ${num(s.value)}；保存前驱 ${s.previous?'B':'A'}。平局取A。`}
  if(e.action==='backtrack')return `沿已保存前驱返回 t=${s.t+1} 的 ${s.state?'B':'A'}；回溯不会重新选择局部最近道路。`;
  if(e.action==='terminal')return `末列最小累计代价 ${s.cost}，终点选 ${s.end?'B':'A'}。下一步才回溯。`;
  if(e.action==='result')return `最优路径 ${s.path.map(i=>i?'B':'A').join('')}，代价 ${s.cost}；局部AAA代价 ${2*p.transition}。`;
  return e.action==='initialize'?'第一列 V₁ = E₁ = [0, 2]；前驱为空。':'每时刻候选A/B；E=[0,2]；BB转移为0，其他转移为参数值。节点格不是道路地图。';
 }
 if(method==='rdp'){
  if(e.action==='distance'){const pts=[[0,0],[1,.2],[2,2],[3,.2],[4,0]],q=pts[s.id],start=pts[s.a],end=pts[s.b],dx=end[0]-start[0],dy=end[1]-start[1];return `u = clamp([(${q[0]}−${start[0]})×${dx}+(${q[1]}−${start[1]})×${dy}]/(${dx}²+${dy}²),0,1) = ${num(s.u)}；垂足 ${num(s.foot)}；d=√[(${q[0]}−${num(s.foot[0])})²+(${q[1]}−${num(s.foot[1])})²]=${num(s.distance)} m。`;}
  if(e.action==='decision')return `最大偏差来自 p${s.id}：${num(s.maximum)} ${s.split?'>':'≤'} ε=${num(p.epsilon)}。${s.split?'保留该点，先递归左侧，再处理右侧。':'不再分裂，由端点线段近似当前区间。'}`;
  if(e.action==='enter')return `进入 [p${s.a},p${s.b}]，递归深度 ${s.depth}。当前区间的距离需要重新计算。`;
  if(e.action==='return')return `完成 [p${s.a},p${s.b}] 并返回；当前保留点 ${s.keep.map(i=>'p'+i).join(', ')}。`;
  if(e.action==='result')return `最终保留 ${s.keep.map(i=>'p'+i).join(', ')}。容差约束几何误差，不保证保留速度、时间或停留语义。`;
  return e.action==='leaf'?'区间内没有中间点，返回父区间。':`五个点，容差 ε=${p.epsilon} m；端点p0、p4始终保留。`;
 }
 if(method==='gps'){
  const r=DATA.raw.find(r=>r.source_id===s.id);
  if(e.action==='duplicate')return `#${s.id} 键=(${r.object_id}, ${r.time}, ${r.x_m}, ${r.y_m})；${s.duplicate?'已出现，记为重复，不再参与速度计算。':'首次出现，下一步计算速度。'}`;
  if(e.action==='speed'){if(s.previous===null)return `#${s.id} 是本对象首条有效候选，无前驱；按初始速度0处理。`;const prev=DATA.raw.find(r=>r.source_id===s.previous);return `上一保留点 #${s.previous}（${prev.time}）；Δt=${s.dt} s；位移=√[(${r.x_m}−${prev.x_m})²+(${r.y_m}−${prev.y_m})²]=${num(s.distance)} m；v=${num(s.distance)}/${s.dt}=${s.speed===null?'时间冲突':num(s.speed)+' m/s'}。`}
  if(e.action==='decision')return `${s.accepted?'通过速度约束，保留':'超出速度阈值或时间冲突，拒绝'} #${s.id}；last 更新/保持为 #${s.last}。${s.accepted?'当前段号 '+s.segment+'；仅间隔 > '+p.gap+' s 才另起一段。':'下一候选仍与 #'+s.last+' 比较，而非刚拒绝的点。'}`;
  if(e.action==='sort')return `按对象、观测时间、来源编号排序：${s.ids.map(i=>'#'+i).join(' → ')}。`;
  if(e.action==='result')return `原始12条 = 重复${s.duplicates.length} + 拒绝${s.rejected.length} + 保留${s.kept.length}。原始记录不修改。`;
  return '读取12条冻结教学GPS记录，先排序，再对每条检查重复、计算速度并决策。';
 }
 if(method==='pca'){
  const points=[[2,0],[0,2],[3,1],[1,3]];
  if(e.action==='mean')return `μ₁=(2+0+3+1)/4=1.5；μ₂=(0+2+1+3)/4=1.5。`;
  if(e.action==='center')return `x${s.id+1} − μ = ${num(points[s.id])} − [1.5, 1.5] = ${num(s.centered)}。`;
  if(e.action==='outer'){const q=a.centered[s.id];return `x_c=${num(q)}；外积=[(${num(q[0])})², (${num(q[0])})×(${num(q[1])}); (${num(q[1])})×(${num(q[0])}), (${num(q[1])})²]=${num([[q[0]*q[0],q[0]*q[1]],[q[1]*q[0],q[1]*q[1]]])}；累加后Σ外积=${num(s.sum)}。`;}
  if(e.action==='covariance')return `S = Σ(x_c x_cᵀ)/(4−1) = ${num(s.covariance)}。`;
  if(e.action==='eigen')return `a=c=5/3，b=−1；λ±=(a+c ± √[(a−c)²+4b²])/2=(10/3 ± 2)/2；得到 ${num(s.eigenvalues)}。`;
  if(e.action==='axis')return `[b,λ₁−a]=[−1,1]；长度√2；归一化并翻转符号，w₁=${num(s.axis)}。`;
  if(e.action==='direction')return `当前方向 w=[cos(${p.angle}°),sin(${p.angle}°)]=${num(s.w)}；−45°为本例第一主轴，其余角度作方向对照。`;
  if(e.action==='project'){let w=[Math.cos(p.angle*Math.PI/180),Math.sin(p.angle*Math.PI/180)],q=a.centered[s.id];return `z${s.id+1}=(${num(q[0])})×(${num(w[0])})+(${num(q[1])})×(${num(w[1])})=${num(s.score)}。`}
  if(e.action==='reconstruct')return `x̂${s.id+1}=μ+z${s.id+1}w=${num(s.point)}；本点平方残差=${num(s.error)}；累计SSE=${num(s.sse)}。`;
  if(e.action==='result')return `当前方向保留方差占比=${num(s.ratio*100)}%；总重构SSE=${num(s.sse)}。方差占比不是预测准确率。`;
  return '四个二维样本，两列视作同尺度；先中心化，后计算协方差。';
 }
}
function plotTrace(method,e,a){if(['impute','signal','scale','interpolate','aggregate'].includes(method))return basicPlot(method,e,a);let body=gridBg(),s=e.state;
 if(method==='matching'){
  for(let t=0;t<3;t++)for(let j=0;j<2;j++){let x=150+t*260,y=110+j*165;if(t<2)for(let k=0;k<2;k++){let now=e.action==='candidate'&&s.t===t+1&&s.i===j&&s.j===k,route=a.path[t]===j&&a.path[t+1]===k;body+=line(x+30,y,x+230,110+k*165,now?C.o:route?C.a:C.l,now||route?'':'5 5',now||route?5:1)}body+=circle(x,y,30,a.path[t]===j?C.a:C.b)+text(x-10,y+7,a.values[t][j]===null?'?':num(a.values[t][j]),'big','var(--bg)')+text(x-45,y-43,`${j?'B':'A'} · E=${j?2:0}`)+text(x-60,y+55,a.back[t][j]===null?'前驱 —':'前驱 '+(a.back[t][j]?'B':'A'),'tiny')}
 }else if(method==='knn'){
  let xx=v=>100+v*100;body=line(70,160,790,160)+text(65,35,'距离计算只使用 A；B缺失，不参与比较');for(const [id,x,b] of [[1,0,10],[2,2,14],[3,6,40]]){let current=s.id===id;body+=circle(xx(x),160,13,current?C.o:a.chosen.includes(id)?C.a:C.b)+text(xx(x)-20,200,`r${id}`)+text(xx(x)-30,230,`B=${b}`);if(a.distances[id]!==undefined)body+=line(xx(p.query),90,xx(x),145,current?C.o:C.l,'4 4')+text(xx(x)-25,275,`d=${num(a.distances[id])}`)}body+=circle(xx(p.query),80,12,C.o)+text(xx(p.query)-30,60,`q: A=${num(p.query)}`)+text(80,345,e.action==='result'?`B̂ = ${num(s.estimate)}`:'B̂ = ?（等待累计完成）','big');
 }else if(method==='pca'){
  const pts=[[2,0],[0,2],[3,1],[1,3]],xy=q=>[300+(q[0]-1.5)*85,190-(q[1]-1.5)*85],angle=p.angle*Math.PI/180,w=[Math.cos(angle),Math.sin(angle)];body=line(65,190,540,190)+line(300,25,300,350);if(['direction','project','reconstruct','result'].includes(e.action))body+=line(300-w[0]*185,190+w[1]*185,300+w[0]*185,190-w[1]*185,C.a,'',3);pts.forEach((q,i)=>{let [x,y]=xy(q);if(a.scores[i]!==undefined){let z=a.scores[i],r=[1.5+z*w[0],1.5+z*w[1]],[rx,ry]=xy(r);body+=line(x,y,rx,ry,C.o,'5 5')+circle(rx,ry,8,a.rec[i]?C.a:C.o)+circle(690,190-z*65,7,C.o)+text(710,190-z*65+(i<2?-9:18),`z${i+1}=${num(z)}`,'tiny')}body+=circle(x,y,10,s.id===i?C.o:C.b)+text(x+12,y-10,'x'+(i+1))});body+=text(65,25,'二维样本 → 逐点投影与重构')+text(610,25,'一维投影');
 }else if(method==='rdp'){
  const pts=[[0,0],[1,.2],[2,2],[3,.2],[4,0]],xy=q=>[100+q[0]*155,310-q[1]*110];body=poly(pts.map(xy),C.m,'5 5');if(s.a!==undefined)body+=line(...xy(pts[s.a]),...xy(pts[s.b]),C.o,'',4);if(s.foot)body+=line(...xy(pts[s.id]),...xy(s.foot),C.r,'5 5')+circle(...xy(s.foot),5,C.r);if(e.action==='result')body+=poly(a.keep.map(i=>xy(pts[i])),C.a,'',5);pts.forEach((q,i)=>body+=circle(...xy(q),a.keep.includes(i)?12:8,s.id===i?C.o:a.keep.includes(i)?C.a:C.b)+text(xy(q)[0]-8,xy(q)[1]+28,'p'+i));body+=text(65,30,'当前区间橙色 · 已保留点绿色 · 距离连线红色');
 }else{
  const xy=q=>[70+q.x_m*.53,330-q.y_m*.29];const inspected=Object.keys(a.gps).map(Number),kept=DATA.raw.filter(r=>a.gps[r.source_id]?.status==='保留');let by={};for(const q of kept){const k=q.object_id+'/'+a.gps[q.source_id].segment;(by[k]??=[]).push(q)}for(const group of Object.values(by))body+=poly(group.map(xy),C.a);for(const q of DATA.raw){let status=a.gps[q.source_id]?.status;if(status==='重复'){const [cx,cy]=xy(q);body+=`<circle cx="${cx}" cy="${cy}" r="11" fill="none" stroke="${s.id===q.source_id?C.o:C.m}" stroke-width="2"/>`}else body+=circle(...xy(q),s.id===q.source_id?12:7,s.id===q.source_id?C.o:status==='保留'?C.a:status==='拒绝'?C.r:C.m);if(s.id===q.source_id)body+=text(Math.max(65,xy(q)[0]-30),Math.max(25,xy(q)[1]-20),'#'+q.source_id,'',C.o)}const prev=s.previous??(s.id!==undefined?a.gps[s.id]?.previous:null);if(prev!==null&&prev!==undefined){let q=DATA.raw.find(r=>r.source_id===s.id),r=DATA.raw.find(r=>r.source_id===prev);body+=line(...xy(r),...xy(q),C.o,'5 5',3)}body+=text(65,25,'灰：未决 · 橙：当前 · 绿：保留 · 红：拒绝；分段不连线');
 }
 return body;
}
function stateTable(method,e,a){
 if(['impute','signal','scale','interpolate','aggregate'].includes(method))return basicTable(method,e,a);
 if(method==='knn')return traceTable(['供体','A','B','距离','是否选中'],[[1,0,10],[2,2,14],[3,6,40]].map(([id,x,b])=>['r'+id,x,b,num(a.distances[id]),a.chosen.includes(id)?'✓':'—']),[1,2,3].indexOf(e.state.id));
 if(method==='pca')return traceTable(['样本','原坐标','中心化','投影 z','重构'],[[2,0],[0,2],[3,1],[1,3]].map((q,i)=>['x'+(i+1),num(q),num(a.centered[i]),num(a.scores[i]),num(a.rec[i])]),e.state.id??-1);
 if(method==='matching')return traceTable(['时刻','V(A)','前驱A','V(B)','前驱B'],a.values.map((r,t)=>['t='+ (t+1),num(r[0]),a.back[t][0]===null?'—':a.back[t][0]?'B':'A',num(r[1]),a.back[t][1]===null?'—':a.back[t][1]?'B':'A']));
 if(method==='rdp')return traceTable(['递归区间','深度','状态'],a.tree.map(n=>['　'.repeat(n.depth)+`[p${n.a},p${n.b}]`,n.depth,n.status]),a.tree.findIndex(n=>n.a===e.state.a&&n.b===e.state.b));
 return traceTable(['候选 / 时间','前一保留点','Δt s','位移 m','速度 m/s','判断 / 段号'],a.gpsOrder.map(id=>a.gps[id]).map(r=>{let q=DATA.raw.find(q=>q.source_id===r.id);return ['#'+r.id+' / '+esc(q.time),r.previous===null?'首点':r.previous===undefined?'—':'#'+r.previous,num(r.dt),num(r.distance),r.speed===null?'时间冲突':num(r.speed),r.status+(r.accepted?' / '+r.segment:'')] }),a.gpsOrder.indexOf(e.state.id));
}
function paintTrace(){const method=TRACE_METHODS[active],trace=traceData();step=Math.max(0,Math.min(step,trace.events.length-1));LABS[active].steps=trace.events.map(detailTitle);const e=trace.events[step],visible=predicting?Math.max(0,step-1):step,a=accumulated(trace.events.slice(0,visible+1)),displayEvent=trace.events[visible];
 $('stage').innerHTML=svg(plotTrace(method,displayEvent,a));$('metrics').innerHTML=[['执行进度',`${step+1} / ${trace.events.length}`],['当前动作',TRACE_TITLES[e.action]],['最终答案',!predicting&&e.action==='result'?'已揭示':'未揭示']].map(([k,v])=>`<div class="metric"><small>${k}</small><strong>${esc(v)}</strong></div>`).join('');
 $('calculation').textContent=predicting?'先预测本步会计算或更新哪个变量，再揭示结果。':explanation(method,e,a);$('explanation').textContent=predicting?'当前图表停留在上一步；点击「揭示本步」后继续。':explanation(method,e,a);$('stepTitle').textContent=detailTitle(e);$('stepNum').textContent=String(step+1).padStart(2,'0');$('stepLabel').textContent=`${step+1} / ${trace.events.length}`;
 $('steps').innerHTML=trace.events.map((v,i)=>`<button aria-label="第${i+1}步 ${esc(detailTitle(v))}" title="${i+1}. ${esc(detailTitle(v))}" onclick="goStep(${i})" class="${i<=visible?'done':''}"></button>`).join('');$('prev').disabled=step===0;$('next').disabled=step===trace.events.length-1;
 $('trace-panel').hidden=false;$('trace-table').innerHTML=stateTable(method,displayEvent,a);const currentRow=$('trace-table').querySelector('.current-row');if(currentRow){const box=$('trace-table').querySelector('.table-scroll');box.scrollTop=Math.max(0,currentRow.getBoundingClientRect().top-box.getBoundingClientRect().top+box.scrollTop-70);}$('trace-question').hidden=!predicting;$('trace-question').innerHTML=`<strong>请先判断：${esc(detailTitle(e))}</strong><p>依据当前表格和参数，下一步数值是多少？会保留、拒绝、分裂，还是更新前驱？</p><button onclick="revealTrace()">揭示本步计算</button>`;
 if($('inline-calc'))$('inline-calc').textContent=$('calculation').textContent;
 const code=CODE_BUNDLE[method],lineno=code.actions[e.action]||1;$('trace-code').innerHTML=code.lines.map((line,i)=>`<div class="code-line ${!predicting&&(code.highlights[e.action]||[lineno]).includes(i+1)?'highlight':''}" id="code-line-${i+1}"><span>${code.start+i}</span><code>${esc(line)}</code></div>`).join('');$('source-name').textContent=`teaching_algorithms.py · ${method}()（高亮计算与执行记录）`;
 const highlighted=$('trace-code').querySelector('.highlight');if(highlighted)$('trace-code').scrollTop=Math.max(0,highlighted.offsetTop-70);
 $('run-command').textContent=`python3 teaching_algorithms.py ${method} `+Object.entries(p).map(([k,v])=>`--${k} ${v}`).join(' ');$('trace-history').innerHTML=trace.events.slice(0,visible+1).map((v,i)=>`<button onclick="goStep(${i})" class="${i===step?'active':''}">${i+1}. ${esc(detailTitle(v))}</button>`).join('');
 $('trace-comparison').innerHTML=compareSnapshot&&compareSnapshot.method===method?`<h3>参数修改前后对照</h3><p>修改前参数：${esc(JSON.stringify(compareSnapshot.parameters))}</p><pre>${esc(JSON.stringify(compareSnapshot.result,null,2))}</pre><p>当前参数：${esc(JSON.stringify(p))}</p><pre>${!predicting&&e.action==='result'?esc(JSON.stringify(trace.result,null,2)):'当前答案暂不揭示；运行到最后一步再比较。'}</pre>`:'<p>先运行到末步，再改变参数，可保留上次结果作对照。参数改变后从输入步骤重新开始。</p>';
 result={lab:LABS[active].short,method,parameters:{...p},step:visible+1,current:displayEvent,history:trace.events.slice(0,visible+1),...(!predicting&&e.action==='result'?{result:trace.result}:{})};$('data').textContent=JSON.stringify(result,null,2);
}
const originalPlay=play;play=function(){predicting=false;originalPlay()};
const originalPaint=paint,originalSelect=selectLab,originalSetParam=setParam,originalAdvance=advance,originalGoStep=goStep;
paint=function(){if(TRACE_METHODS[active])paintTrace();else{if($('trace-panel'))$('trace-panel').hidden=true;originalPaint()}$('trace-tools').hidden=!TRACE_METHODS[active]};
selectLab=function(i){predicting=false;traceKey='';compareSnapshot=null;originalSelect(i)};
setParam=function(key,value){if(TRACE_METHODS[active]){const trace=traceData();if(step===trace.events.length-1&&!predicting)compareSnapshot={method:TRACE_METHODS[active],parameters:{...p},result:trace.result};stop();step=0;predicting=false;traceKey=''}originalSetParam(key,value)};
advance=function(d){if(predicting&&d>0){revealTrace();return}predicting=false;originalAdvance(d)};goStep=function(i){predicting=false;originalGoStep(i)};
function nextDecision(){stop();predicting=false;const tr=traceData();let i=step+1;while(i<tr.events.length-1&&!['select','update','decision','terminal','result','eigen','direction','statistics','fit','assign'].includes(tr.events[i].action))i++;goStep(Math.min(i,tr.events.length-1))}
function predictNext(){stop();const tr=traceData();if(step<tr.events.length-1)step++;predicting=true;paint()}
function revealTrace(){predicting=false;paint()}
function downloadPython(){const blob=new Blob([PYTHON_SOURCE],{type:'text/x-python;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='teaching_algorithms.py';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function downloadGPS(){const blob=new Blob([GPS_CSV],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='gps_raw.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}

function basicExplanation(method,e,a){let s=e.state,b=a.basic;
 if(method==='impute'){if(e.action==='sort')return `观测排序为 ${num(s.ordered)}；中间两项为3和4。`;if(e.action==='sum')return `加入观测${s.id+1}：${s.value}，累计总和=${s.total}。`;if(e.action==='statistics')return `均值=109/4=${s.mean}；中位数=(3+4)/2=${s.median}。`;if(e.action==='result')return `选择${p.method==='mean'?'均值':'中位数'}填补，估计=${num(s.estimate)}；缺失标记仍保留。`;return '观测=[2,3,4,100]；第五项缺失。先比较极端值对不同估计的影响。'}
 if(method==='signal'){if(e.action==='window')return `时刻${s.id+1}，后向窗口=${num(s.values)}；起始不足窗口时使用已有观测。`;if(e.action==='average')return `平滑值=窗口内总和 / 当前有效项数=${num(b.window.values.reduce((a,b)=>a+b,0))}/${b.window.values.length}=${num(s.average)}。`;if(e.action==='zscore')return `独立异常例：Z=(68−50)/5=${s.score}；参考μ和σ不是由上方序列估计。`;if(e.action==='decision')return `|${s.score}| ${s.flag?'>':'≤'} 阈值${s.threshold}；${s.flag?'标记为异常候选，等待核查':'不超阈值'}。`;if(e.action==='result')return `完成${s.smoothed.length}个后向均值；尖峰平滑后=${num(s.smoothed[5])}。窗口可能抹平真实信号。`;return `先逐窗口平滑，再用独立参考算例判断异常；w=${p.window}。`}
 if(method==='scale'){if(e.action==='fit')return `拟合集=${num(s.fit)}；a=${s.low}，b=${s.high}。${p.leak==='all'?'这是包含测试值的泄漏对照。':'测试值40不参与拟合。'}`;if(e.action==='transform')return `${s.value} → (${s.value}−${b.fit.low})/(${b.fit.high}−${b.fit.low})=${num(s.scaled)}。`;if(e.action==='standardize')return `μ=${num(s.mean)}；σ=√[Σ(x−μ)²/n]=${num(s.std)}；测试Z=(40−μ)/σ=${num(s.test_z)}。`;if(e.action==='encode')return `已知类别顺序[A,B]：${s.category} → ${num(s.code)}。`;if(e.action==='result')return `四个Min-Max结果=${num(s.scaled)}。训练范围外的测试值可以大于1。`;return '前三个值为训练数据，40为测试值；先明确拟合参考集，再变换。'}
 if(method==='interpolate'){if(e.action==='interval')return 'Δt = 08:07 − 08:04 = 3×60 = 180秒。';if(e.action==='decision')return `180 ${s.split?'>':'≤'} 分段阈值${s.gap}秒：${s.split?'分段，保留未知区间':'本规则不分段'}。`;if(e.action==='weight')return `α=${s.alpha}，目标时刻距起点${num(s.elapsed)}秒；α=(t−tₐ)/(tᵦ−tₐ)。`;if(e.action==='coordinate')return `${s.id===0?'x̂':'ŷ'}=(1−${p.alpha})×${s.id===0?800:200}+${p.alpha}×${s.id===0?930:240}=${num(s.value)}。`;if(e.action==='result')return `线性估计位置=${num(s.estimate)}，并非真实观测。插值和分段回答不同问题。`;return '两个端点分别为08:04 (800,200)、08:07 (930,240)。分段与事后插值分别演示。'}
 if(method==='aggregate'){if(e.action==='assign'){const q=DATA.raw.find(q=>q.source_id===s.id);return `#${s.id}：gx=⌊${q.x_m}/${p.cell}⌋=${s.gx}，gy=⌊${q.y_m}/${p.cell}⌋=${s.gy}；时间窗=⌊${sec(q.time)}/${p.window}⌋=${s.tw}。键=${s.key}。`}if(e.action==='increment')return `组${s.key}：点计数更新为${s.points}；设备集合去重后为${s.devices}台。`;if(e.action==='result')return `得到${s.groups.length}个格网×时间组；统计字段为${p.count==='points'?'轨迹点数':'设备去重数'}。同一设备多次采样不会变成多台设备。`;return '固定使用12 m/s速度阈值、120秒分段得到的10个保留点；与GPS页当前滑块独立。'}
}
function basicTable(method,e,a){const b=a.basic;
 if(method==='impute')return traceTable(['记录','观测值','累计和','缺失标记'],[2,3,4,100,null].map((v,i)=>['x'+(i+1),v===null?(b.result?num(b.result.estimate):'?'):v,num(a.rows[i]?.total),i===4?'1（原本缺失）':'0']));
 if(method==='signal')return traceTable(['时刻','原始值','本步窗口','后向均值'],[10,11,10,12,11,50,12,11,10,12,11].map((v,i)=>[i+1,v,num(a.windows[i]),num(a.rows[i]?.average)]));
 if(method==='scale')return traceTable(['记录','原始值','角色','Min-Max结果'],[10,20,30,40].map((v,i)=>[i+1,v,i===3?'测试':'训练',num(a.rows[i]?.scaled)]));
 if(method==='interpolate')return traceTable(['坐标','起点','终点','估计'],[['x',800,930,num(a.rows[0]?.value)],['y',200,240,num(a.rows[1]?.value)]]);
 return traceTable(['格网x/y/时间窗','点计数','设备去重数','当前统计值'],Object.entries(a.groups).map(([k,g])=>[esc(k),g.points,g.devices,p.count==='points'?g.points:g.devices]));
}
function basicPlot(method,e,a){let body=gridBg(),b=a.basic,s=e.state;
 if(method==='impute'){const vals=[2,3,4,100,b.result?.estimate??null];vals.forEach((v,i)=>{const x=110+i*140;body+=rect(x,310-(v||0)*2.35,65,(v||0)*2.35,i===4?C.o:C.b)+text(x,290-(v||0)*2.35,v===null?'?':num(v))+text(x,345,'x'+(i+1))});return body}
 if(method==='signal'){let raw=[10,11,10,12,11,50,12,11,10,12,11];const xy=(v,i)=>[80+i*66,260-v*3.6];body+=poly(raw.map(xy),C.m);let sm=Object.entries(a.rows).map(([id,r])=>xy(r.average,+id));if(sm.length)body+=poly(sm,C.a,'',4);if(s.id!==undefined)body+=circle(...xy(raw[s.id],s.id),11,C.o);body+=text(65,30,'灰：原始序列 · 绿：已计算的后向均值')+text(65,350,b.zscore?`独立Z算例：${b.zscore.score}；${b.decision?(b.decision.flag?'超阈值':'不超阈值'):'等待判断'}`:'逐窗口计算，未计算的平滑值不显示');return body}
 if(method==='scale'){body=text(65,35,'上：原值，蓝色为训练，橙色为测试 · 下：已完成映射')+line(70,120,790,120)+line(70,270,790,270);[10,20,30,40].forEach((v,i)=>{body+=circle(120+i*190,120,10,i===3?C.o:C.b)+text(110+i*190,90,v);if(a.rows[i]){const xx=120+a.rows[i].scaled*370;body+=line(120+i*190,135,xx,250,C.l,'5 5')+circle(xx,270,10,i===3?C.o:C.a)+text(xx-10,305,num(a.rows[i].scaled))}});return body}
 if(method==='interpolate'){body+=circle(170,260,12,C.b)+circle(660,105,12,C.b)+text(90,310,'08:04 (800,200)')+text(550,75,'08:07 (930,240)');if(b.decision&&!b.decision.split)body+=line(170,260,660,105,C.a);if(b.decision?.split)body+=text(300,200,'分段：保留未知区间','',C.o);if(b.result)body+=line(170,260,660,105,C.o,'5 5')+circle(170+490*p.alpha,260-155*p.alpha,13,C.o)+text(300,350,`事后估计 ${num(b.result.estimate)}`,'big');return body}
 body=text(65,30,'逐组累计 · 每根柱表示一个格网×时间窗组');const groups=Object.entries(a.groups);groups.forEach(([key,g],i)=>{const value=p.count==='points'?g.points:g.devices,x=75+i*62;body+=rect(x,300-value*45,40,value*45,C.a)+text(x+12,280-value*45,value)+text(x,330,'g'+(i+1),'tiny')});if(s.id!==undefined)body+=text(65,365,`当前分组记录 #${s.id} → ${s.key}`,'tiny');return body;
}

let processView=true;
const traceState=document.querySelector('.trace-state'),codePanel=document.querySelector('.code-panel'),traceLayout=document.querySelector('.trace-layout'),theory=document.querySelector('.theory');
const inlineCalc=document.createElement('p');inlineCalc.id='inline-calc';inlineCalc.className='inline-calc';codePanel.insertBefore(inlineCalc,codePanel.children[1]);
function arrangeTrace(){document.body.classList.toggle('process-view',processView);$('view-mode').textContent=processView?'切换理论视图':'切换过程视图';if(processView){document.querySelector('article').append(traceState);theory.append(codePanel);document.querySelector('article').insertBefore($('trace-question'),$('stage'))}else{traceLayout.append(traceState,codePanel);$('trace-panel').prepend($('trace-question'))}if(TRACE_METHODS[active])paint()}
function toggleView(){processView=!processView;arrangeTrace()}
arrangeTrace();selectLab(0);
