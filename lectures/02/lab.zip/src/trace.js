/* Pure teaching algorithms: browser execution events mirror teaching_algorithms.py. */
function computeTrace(method,p,raw=[]){
 const sec=t=>t.split(':').reduce((s,v,i)=>s+Number(v)*[3600,60,1][i],0);
 const events=[];const emit=(action,state)=>events.push({action,state:JSON.parse(JSON.stringify(state))});let result;
 if(method==='knn'){
  const donors=[[1,0,10],[2,2,14],[3,6,40]],distances=[];emit('input',{query:p.query,k:p.k,donors});
  for(const [id,a,b] of donors){const distance=Math.abs(p.query-a);distances.push([distance,id,b]);emit('distance',{id,distance})}
  distances.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);emit('sort',{order:distances.map(r=>r[1])});
  const chosen=distances.slice(0,p.k);emit('select',{ids:chosen.map(r=>r[1])});let total=0;
  for(const [distance,id,b] of chosen){total+=b;emit('sum',{id,total})}
  const estimate=total/chosen.length;emit('result',{estimate});result={estimate,ids:chosen.map(r=>r[1])};
 }else if(method==='pca'){
  const points=[[2,0],[0,2],[3,1],[1,3]],n=points.length;emit('input',{points});
  const mean=[0,1].map(j=>points.reduce((s,q)=>s+q[j],0)/n);emit('mean',{mean});let centered=[];
  points.forEach((q,id)=>{centered.push(q.map((v,j)=>v-mean[j]));emit('center',{id,centered:centered[id]})});
  const sum=[[0,0],[0,0]];centered.forEach((q,id)=>{for(let a=0;a<2;a++)for(let b=0;b<2;b++)sum[a][b]+=q[a]*q[b];emit('outer',{id,sum})});
  const covariance=sum.map(r=>r.map(v=>v/(n-1)));emit('covariance',{covariance});
  const a=covariance[0][0],b=covariance[0][1],c=covariance[1][1],delta=Math.sqrt((a-c)**2+4*b*b),eigenvalues=[(a+c+delta)/2,(a+c-delta)/2];emit('eigen',{eigenvalues});
  let axis=[b,eigenvalues[0]-a],norm=Math.hypot(...axis);axis=axis.map(v=>-v/norm);emit('axis',{axis});
  const w=[Math.cos(p.angle*Math.PI/180),Math.sin(p.angle*Math.PI/180)];emit('direction',{angle:p.angle,w});
  const scores=[];centered.forEach((q,id)=>{scores.push(q.reduce((s,v,j)=>s+v*w[j],0));emit('project',{id,score:scores[id]})});
  const reconstruction=[];let sse=0;scores.forEach((z,id)=>{const point=mean.map((v,j)=>v+z*w[j]);reconstruction.push(point);const error=point.reduce((s,v,j)=>s+(points[id][j]-v)**2,0);sse+=error;emit('reconstruct',{id,point,error,sse})});
  const ratio=scores.reduce((s,z)=>s+z*z,0)/(n-1)/(eigenvalues[0]+eigenvalues[1]);emit('result',{ratio,sse});result={scores,reconstruction,sse,ratio,covariance,eigenvalues};
 }else if(method==='matching'){
  const emission=[0,2],values=[emission.slice()],back=[[null,null]];emit('input',{emission,transition:p.transition});emit('initialize',{values:values[0]});
  for(let t=1;t<3;t++){let row=[],predecessors=[];for(let j=0;j<2;j++){let candidates=[];for(let i=0;i<2;i++){const cost=i===1&&j===1?0:p.transition;candidates.push(values[t-1][i]+cost);emit('candidate',{t,j,i,candidate:candidates[i]})}const previous=candidates[0]<=candidates[1]?0:1;row.push(emission[j]+candidates[previous]);predecessors.push(previous);emit('update',{t,j,value:row[j],previous})}values.push(row);back.push(predecessors)}
  let end=values[2][0]<=values[2][1]?0:1;const path=[end];emit('terminal',{end,cost:values[2][end]});for(let t=2;t>0;t--){end=back[t][end];path.unshift(end);emit('backtrack',{t:t-1,state:end})}emit('result',{path,cost:Math.min(...values[2])});result={path,cost:Math.min(...values[2]),values,back};
 }else if(method==='rdp'){
  const points=[[0,0],[1,.2],[2,2],[3,.2],[4,0]],keep=new Set([0,4]);emit('input',{points,epsilon:p.epsilon});
  function visit(a,b,depth=0){emit('enter',{a,b,depth});if(b-a<=1){emit('leaf',{a,b});return}const dx=points[b][0]-points[a][0],dy=points[b][1]-points[a][1];let maximum=-1,index=null;for(let i=a+1;i<b;i++){const den=dx*dx+dy*dy;let u=den?((points[i][0]-points[a][0])*dx+(points[i][1]-points[a][1])*dy)/den:0;u=Math.max(0,Math.min(1,u));const foot=[points[a][0]+u*dx,points[a][1]+u*dy],distance=Math.hypot(points[i][0]-foot[0],points[i][1]-foot[1]);if(distance>maximum){maximum=distance;index=i}emit('distance',{a,b,id:i,u,foot,distance})}const split=maximum>p.epsilon;emit('decision',{a,b,id:index,maximum,split});if(split){keep.add(index);visit(a,index,depth+1);visit(index,b,depth+1)}emit('return',{a,b,keep:[...keep].sort((a,b)=>a-b)})}
  visit(0,4);result={keep:[...keep].sort((a,b)=>a-b)};emit('result',result);
 }else if(method==='gps'){
  const rows=raw.map(r=>({...r}));emit('input',{count:rows.length});rows.sort((a,b)=>a.object_id.localeCompare(b.object_id)||a.time.localeCompare(b.time)||a.source_id-b.source_id);emit('sort',{ids:rows.map(r=>r.source_id)});
  const seen=new Set(),last={},segments={},kept=[],rejected=[],duplicates=[];
  for(const r of rows){const id=r.source_id,key=JSON.stringify([r.object_id,r.time,+r.x_m,+r.y_m]),duplicate=seen.has(key);emit('duplicate',{id,duplicate});if(duplicate){duplicates.push(id);continue}seen.add(key);const prev=last[r.object_id],dt=prev?sec(r.time)-sec(prev.time):null,distance=prev?Math.hypot(r.x_m-prev.x_m,r.y_m-prev.y_m):null,v=prev?(dt>0?distance/dt:Infinity):0;emit('speed',{id,previous:prev?prev.source_id:null,dt,distance,speed:Number.isFinite(v)?v:null});const accepted=v<=p.speed;if(accepted){const segment=(segments[r.object_id]||1)+(prev&&dt>p.gap?1:0);segments[r.object_id]=segment;last[r.object_id]=r;kept.push(id)}else rejected.push(id);emit('decision',{id,accepted,last:last[r.object_id]?last[r.object_id].source_id:null,segment:segments[r.object_id]||1})}
  result={kept,rejected,duplicates};emit('result',result);
 }
 if(method==='impute'){
  const observed=[2,3,4,100];emit('input',{observed,method:p.method});const ordered=[...observed].sort((a,b)=>a-b);emit('sort',{ordered});let total=0;observed.forEach((value,id)=>{total+=value;emit('sum',{id,value,total})});const mean=total/4,median=(ordered[1]+ordered[2])/2;emit('statistics',{mean,median});const estimate=p.method==='mean'?mean:median;result={estimate,filled:[...observed,estimate]};emit('result',result);
 }else if(method==='signal'){
  const raw=[10,11,10,12,11,50,12,11,10,12,11];emit('input',{raw,window:p.window});const smoothed=[];for(let id=0;id<raw.length;id++){const values=raw.slice(Math.max(0,id-p.window+1),id+1);emit('window',{id,values});const average=values.reduce((a,b)=>a+b,0)/values.length;smoothed.push(average);emit('average',{id,average})}const score=(68-50)/5;emit('zscore',{value:68,mean:50,std:5,score});const flag=Math.abs(score)>p.z;emit('decision',{score,threshold:p.z,flag});result={smoothed,score,flag};emit('result',result);
 }else if(method==='scale'){
  const values=[10,20,30,40];emit('input',{values,leak:p.leak});const fit=p.leak==='all'?values:values.slice(0,3),low=Math.min(...fit),high=Math.max(...fit);emit('fit',{fit,low,high});const scaled=[];values.forEach((value,id)=>{const transformed=(value-low)/(high-low);scaled.push(transformed);emit('transform',{id,value,scaled:transformed})});const mean=fit.reduce((a,b)=>a+b,0)/fit.length,std=Math.sqrt(fit.reduce((s,v)=>s+(v-mean)**2,0)/fit.length);emit('standardize',{mean,std,test_z:(40-mean)/std});const codes=[];for(const category of ['A','B']){const code=['A','B'].map(c=>Number(category===c));codes.push(code);emit('encode',{category,code})}result={scaled,test_z:(40-mean)/std,codes};emit('result',result);
 }else if(method==='interpolate'){
  const start=[800,200],end=[930,240];emit('input',{start,end});const interval=3*60;emit('interval',{interval});const split=interval>p.gap;emit('decision',{interval,gap:p.gap,split});emit('weight',{alpha:p.alpha,elapsed:interval*p.alpha});const estimate=[];for(let id=0;id<2;id++){const value=(1-p.alpha)*start[id]+p.alpha*end[id];estimate.push(value);emit('coordinate',{id,value})}result={estimate,split};emit('result',result);
 }else if(method==='aggregate'){
  const kept=computeTrace('gps',{speed:12,gap:120},raw).result.kept;const rows=raw.filter(r=>kept.includes(r.source_id)).slice().sort((a,b)=>a.object_id.localeCompare(b.object_id)||a.time.localeCompare(b.time)||a.source_id-b.source_id);emit('input',{count:rows.length,cell:p.cell,window:p.window});const groups=new Map();for(const r of rows){const gx=Math.floor(r.x_m/p.cell),gy=Math.floor(r.y_m/p.cell),tw=Math.floor(sec(r.time)/p.window),key=`${gx}/${gy}/${tw}`;emit('assign',{id:r.source_id,gx,gy,tw,key});if(!groups.has(key))groups.set(key,{points:0,devices:new Set()});const g=groups.get(key);g.points++;g.devices.add(r.object_id);emit('increment',{key,points:g.points,devices:g.devices.size})}result={groups:[...groups].map(([key,g])=>({key,points:g.points,devices:g.devices.size})),count:p.count};emit('result',result);
 }
 return {events,result};
}
if(typeof module!=='undefined')module.exports={computeTrace};
