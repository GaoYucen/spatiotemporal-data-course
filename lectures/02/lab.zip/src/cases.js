/* Reproducible synthetic benchmarks for the classroom comparisons. */
function syntheticCases(seed=20261106) {
  let state=seed>>>0;
  const uniform=()=>((state=(Math.imul(state,1664525)+1013904223)>>>0)/4294967296);
  const noise=()=>Array.from({length:6},uniform).reduce((a,b)=>a+b,0)-3;
  const sensors=Array.from({length:420},(_,i)=>{
    const zone=i%3, flow=25+zone*18+14*noise(), length=1100+zone*480+220*noise();
    const time=5+.15*flow+.004*length+1.6*noise();
    return {id:i+1,zone,flow,length,time,missing:i%11===0 || (zone===2 && i%5===2),
      observedTime:time+(i%53===0?45:0)};
  });
  const signal=Array.from({length:480},(_,i)=>{
    const reference=24+5*Math.sin(i/23)+(i>=255?12:0), spike=i%47===19;
    return {i,reference,spike,value:reference+2.3*noise()+(spike?21:0)};
  });
  const gps=[];
  const add=(device,t,x,y,status)=>gps.push({id:gps.length+1,device,t,x,y,status});
  for(let d=0;d<24;d++)for(let j=0;j<144;j++){
    if(j>=54 && j<65 && d%3===0)continue;
    const t=j*20, x=150+j*11+55*Math.sin(j/16+d),y=100+d*32+38*Math.sin(j/19+d);
    const jump=(j+d*5)%79===26;
    add(d,t,x+(jump?420:0),y+(jump?300:0),jump?'注入跳点':'正常');
    if((j+d*3)%61===10)add(d,t,x+(jump?420:0),y+(jump?300:0),'注入重复');
  }
  const trajectory=Array.from({length:360},(_,i)=>[i*3.2,100+66*Math.sin(i/38)+22*Math.sin(i/9)+2*noise()]);
  const missingRanges=[[42,48],[115,134],[200,212],[260,302]];
  const observed=trajectory.map(([x,y],i)=>({t:i*10,x,y})).filter((_,i)=>!missingRanges.some(([a,b])=>i>=a&&i<=b));
  const roadY=[140,178,236];
  const matching=Array.from({length:42},(_,i)=>{
    const truth=i<23?1:2;
    return {i,x:40+i*18,y:roadY[truth]+noise()*22+(i%8===4?-29:0),truth};
  });
  return {seed,sensors,signal,gps,trajectory,observed,roadY,matching};
}
const CASES=syntheticCases();
const mean=xs=>xs.reduce((sum,x)=>sum+x,0)/xs.length;
const quantile=(sorted,q)=>{const i=(sorted.length-1)*q,k=Math.floor(i);return sorted[k]+(sorted[Math.min(k+1,sorted.length-1)]-sorted[k])*(i-k)};
const deviation=xs=>{const m=mean(xs);return Math.sqrt(mean(xs.map(x=>(x-m)**2)))};
const mae=(rows,estimate,truth)=>mean(rows.map((row,i)=>Math.abs(estimate[i]-truth(row))));
function cleanCase(rows,speed,gap) {
  const ordered=[...rows].sort((a,b)=>a.device-b.device || a.t-b.t || a.id-b.id);
  const kept=[],rejected=[],duplicates=[],seen=new Set(),last=new Map();
  for(const row of ordered){
    const key=[row.device,row.t,row.x,row.y].join('/');
    if(seen.has(key)){duplicates.push(row);continue}
    seen.add(key);
    const previous=last.get(row.device);
    const delta=previous?row.t-previous.t:0;
    const velocity=previous?(delta>0?Math.hypot(row.x-previous.x,row.y-previous.y)/delta:Infinity):0;
    if(velocity>speed){rejected.push({...row,velocity:Number.isFinite(velocity)?velocity:null});continue}
    const segment=previous?previous.segment+Number(delta>gap):1;
    const item={...row,segment};
    kept.push(item);
    last.set(row.device,item);
  }
  return {kept,rejected,duplicates};
}
const CLEAN_REFERENCE=cleanCase(CASES.gps,12,120);

function complexCase(method,p){
  const {sensors,signal,gps,trajectory,observed,matching,roadY}=CASES;
  if(method==='impute'||method==='knn'){
    const reference=sensors.filter(q=>!q.missing),masked=sensors.filter(q=>q.missing);
    const values=reference.map(q=>q.observedTime).sort((a,b)=>a-b);
    const baseline=quantile(values,.5);
    let estimates,neighbors=[];
    if(method==='impute'){
      estimates=masked.map(()=>p.method==='mean'?mean(values):baseline);
    }else{
      const columns=['flow','length'];
      const scales=columns.map(k=>p.units==='raw'?1:deviation(reference.map(q=>q[k])));
      neighbors=masked.map(q=>reference.map(r=>({id:r.id,time:r.observedTime,distance:Math.hypot(...columns.map((k,i)=>(q[k]-r[k])/scales[i]))}))
        .sort((a,b)=>a.distance-b.distance||a.id-b.id).slice(0,p.k));
      estimates=neighbors.map(ns=>mean(ns.map(r=>r.time)));
    }
    return {reference,masked,estimates,neighbors,baseline,
      error:mae(masked,estimates,q=>q.time),baselineError:mae(masked,masked.map(()=>baseline),q=>q.time)};
  }
  if(method==='signal'){
    const smoothed=signal.map((_,i)=>mean(signal.slice(Math.max(0,i-p.window+1),i+1).map(q=>q.value)));
    const residual=signal.map((q,i)=>i>=p.window?q.value-smoothed[i-1]:null);
    const reference=residual.slice(p.window,200).filter((_,i)=>!signal[i+p.window].spike);
    const center=mean(reference),sigma=deviation(reference);
    const flagged=signal.filter((q,i)=>residual[i]!==null && Math.abs(residual[i]-center)>p.z*sigma).map(q=>q.i);
    const hits=flagged.filter(i=>signal[i].spike).length;
    return {signal,smoothed,residual,center,sigma,flagged,hits,spikes:signal.filter(q=>q.spike).length};
  }
  if(method==='scale'){
    const values=sensors.map((q,i)=>q.flow+(i>=320?38:0));
    const train=values.slice(0,320),test=values.slice(320);
    const fit=p.leak==='all'?values:train,low=Math.min(...fit),high=Math.max(...fit);
    const transformed=values.map(x=>(x-low)/(high-low));
    return {train,test,low,high,transformed,outside:transformed.slice(320).filter(x=>x<0||x>1).length,
      categories:sensors.map(q=>[0,1,2].map(zone=>Number(q.zone===zone)))};
  }
  if(method==='pca'){
    const points=sensors.map(q=>[q.flow,q.time]);
    const center=[mean(points.map(q=>q[0])),mean(points.map(q=>q[1]))];
    const units=[0,1].map(j=>p.units==='raw'?1:deviation(points.map(q=>q[j])));
    const centered=points.map(q=>q.map((v,j)=>(v-center[j])/units[j]));
    const cov=[0,1].map(i=>[0,1].map(j=>centered.reduce((s,q)=>s+q[i]*q[j],0)/(points.length-1)));
    const theta=.5*Math.atan2(2*cov[0][1],cov[0][0]-cov[1][1]);
    const angle=p.direction==='axis'?theta:p.angle*Math.PI/180;
    const w=[Math.cos(angle),Math.sin(angle)];
    const scores=centered.map(q=>q[0]*w[0]+q[1]*w[1]);
    const reconstruction=scores.map(z=>w.map(v=>v*z));
    const sse=centered.reduce((s,q,i)=>s+(q[0]-reconstruction[i][0])**2+(q[1]-reconstruction[i][1])**2,0);
    const total=centered.reduce((s,q)=>s+q[0]**2+q[1]**2,0);
    return {points,center,units,centered,cov,theta,angle,w,scores,reconstruction,sse,ratio:1-sse/total};
  }
  if(method==='gps')return {rows:gps,...cleanCase(gps,p.speed,p.gap)};
  if(method==='interpolate'){
    const gaps=[],estimates=[];
    for(let i=1;i<observed.length;i++){
      const start=observed[i-1],end=observed[i],interval=end.t-start.t;
      if(interval<=10)continue;
      const split=interval>p.gap;
      gaps.push({start,end,interval,split});
      if(split)continue;
      for(let t=start.t+10;t<end.t;t+=10){
        const alpha=(t-start.t)/interval,x=start.x+alpha*(end.x-start.x),y=start.y+alpha*(end.y-start.y);
        const truth=trajectory[t/10];
        estimates.push({t,x,y,error:Math.hypot(x-truth[0],y-truth[1])});
      }
    }
    return {observed,gaps,estimates,unknown:trajectory.length-observed.length-estimates.length,
      rmse:estimates.length?Math.sqrt(mean(estimates.map(q=>q.error**2))):null};
  }
  if(method==='matching'){
    const emission=matching.map(q=>roadY.map(y=>((q.y-y)/22)**2));
    // Road changes are allowed at two connectors; elsewhere a large cost penalizes switching.
    const transition=(t,i,j)=>i===j?0:([12,23,33].includes(t)?p.transition*.3:p.transition);
    const values=[emission[0].slice()],back=[[-1,-1,-1]];
    for(let t=1;t<matching.length;t++){
      const previous=values[t-1];
      back.push(roadY.map((_,j)=>previous.map((v,i)=>v+transition(t,i,j)).reduce((best,v,i,a)=>v<a[best]?i:best,0)));
      values.push(roadY.map((_,j)=>emission[t][j]+previous[back[t][j]]+transition(t,back[t][j],j)));
    }
    const last=values.at(-1),cost=Math.min(...last),path=[last.indexOf(cost)];
    for(let t=matching.length-1;t>0;t--)path.unshift(back[t][path[0]]);
    const nearest=emission.map(r=>r.indexOf(Math.min(...r)));
    const score=route=>route.reduce((s,j,t)=>s+emission[t][j]+(t?transition(t,route[t-1],j):0),0);
    const accuracy=route=>route.filter((j,i)=>j===matching[i].truth).length;
    const disagreement=path.findIndex((j,t)=>j!==nearest[t]);
    const example=disagreement<0?null:{
      index:disagreement,
      emissionSaving:emission[disagreement][path[disagreement]]-emission[disagreement][nearest[disagreement]],
      extraTotal:score(path.map((j,t)=>t===disagreement?nearest[t]:j))-cost,
    };
    return {matching,roadY,values,back,path,nearest,cost,nearestCost:score(nearest),correct:accuracy(path),nearestCorrect:accuracy(nearest),example};
  }
  if(method==='rdp'){
    const points=trajectory;
    const distance=(q,a,b)=>{
      const dx=b[0]-a[0],dy=b[1]-a[1],den=dx*dx+dy*dy;
      const t=den?Math.max(0,Math.min(1,((q[0]-a[0])*dx+(q[1]-a[1])*dy)/den)):0;
      return Math.hypot(q[0]-a[0]-t*dx,q[1]-a[1]-t*dy);
    };
    const indices=new Set([0,points.length-1]),stack=[[0,points.length-1]];
    while(stack.length){
      const [a,b]=stack.pop();let farthest=-1,max=p.epsilon;
      for(let i=a+1;i<b;i++){const d=distance(points[i],points[a],points[b]);if(d>max){max=d;farthest=i}}
      if(farthest>=0){indices.add(farthest);stack.push([a,farthest],[farthest,b])}
    }
    const keep=[...indices].sort((a,b)=>a-b);
    let maxError=0;
    for(let j=1;j<keep.length;j++)for(let i=keep[j-1]+1;i<keep[j];i++)maxError=Math.max(maxError,distance(points[i],points[keep[j-1]],points[keep[j]]));
    return {points,keep,maxError};
  }
  const rows=CLEAN_REFERENCE.kept;
  const buckets=new Map();
  for(const row of rows){
    const x=Math.floor(row.x/p.cell),y=Math.floor(row.y/p.cell),t=Math.floor(row.t/p.window),key=[x,y,t].join('/');
    if(!buckets.has(key))buckets.set(key,{x,y,t,points:0,devices:new Set()});
    const bucket=buckets.get(key);bucket.points++;bucket.devices.add(row.device);
  }
  const groups=[...buckets.values()].map(q=>({...q,devices:q.devices.size}));
  return {rows,groups,maxTime:Math.max(...groups.map(g=>g.t))};
}
