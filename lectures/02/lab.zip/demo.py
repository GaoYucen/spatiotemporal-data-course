import csv, math, json, argparse
from pathlib import Path
P=Path(__file__).resolve().parent

def run(speed=12,gap=120):
    with (P/'data/gps_raw.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    for i,r in enumerate(rows): r['source_id']=i+1
    rows.sort(key=lambda r:(r['object_id'],r['time'],r['source_id']))
    unique=[]; seen=set(); duplicates=[]
    for r in rows:
        key=tuple(r[k] for k in ('object_id','time','x_m','y_m'))
        if key in seen: duplicates.append({**r,'status':'重复','reason':'对象、时间、坐标完全一致'})
        else: unique.append(r);seen.add(key)
    kept=[];rejected=[];last={};segments={}
    def sec(t):
        h,m,s=map(int,t.split(':'));return 3600*h+60*m+s
    for r in unique:
        prev=last.get(r['object_id']);dt=sec(r['time'])-sec(prev['time']) if prev else None
        v=math.hypot(float(r['x_m'])-float(prev['x_m']),float(r['y_m'])-float(prev['y_m']))/dt if prev and dt>0 else (float('inf') if prev else 0)
        if v>speed:
            rejected.append({**r,'status':'拒绝','reason':'速度超阈值或时间冲突','speed_mps':round(v,3) if math.isfinite(v) else None});continue
        seg=segments.get(r['object_id'],1)+(1 if prev and dt>gap else 0);segments[r['object_id']]=seg
        q={**r,'status':'保留','reason':'通过速度规则','speed_mps':round(v,3),'gap_s':dt,'segment':seg};kept.append(q);last[r['object_id']]=q
    return {'raw':rows,'duplicates':duplicates,'clean':kept,'rejected':rejected,'speed':speed,'gap':gap}

def main():
    p=argparse.ArgumentParser();p.add_argument('--speed',type=float,default=12);p.add_argument('--gap',type=float,default=120);a=p.parse_args()
    if not math.isfinite(a.speed) or not math.isfinite(a.gap) or a.speed<=0 or a.gap<=0:
        p.error('speed and gap must be finite and positive')
    from build_studio import build
    build(a.speed,a.gap)
if __name__=='__main__':main()
