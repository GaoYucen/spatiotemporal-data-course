# GPS 与时空预处理实验

解压整个 ZIP，保留文件夹结构。双击「开始演示.html」可离线查看课堂演示。

在解压目录启动 Jupyter，打开「代码讲解.ipynb」并按顺序运行各单元。Python 脚本使用标准库。

GPS CSV 包含课件中的 12 条模拟记录。命令会输出速度检查与分段结果。扩展实验 Notebook 使用实验台 v6 的简单用例。运行 python3 demo.py 可重建离线演示。

```sh
python3 teaching_algorithms.py gps --speed 12 --gap 120
```

复核课件中排序、去重和速度过滤的演示，可在本目录执行 `python3 run.py`。输出写入 `outputs/`。
