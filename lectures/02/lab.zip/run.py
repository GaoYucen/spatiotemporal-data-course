from pathlib import Path
import csv,json,math,argparse
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)
def read(name):
 with (ROOT/'data'/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def save(rows,name):
 if rows:
  with (OUT/name).open('w',newline='',encoding='utf-8') as f:
   w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def report(d):
 (OUT/'metrics.json').write_text(json.dumps(d,ensure_ascii=False,indent=2));print(json.dumps(d,ensure_ascii=False,indent=2))
def plot(values,name='result.svg'):
 # Standard-library SVG plot, no PowerPoint environment required.
 minimum=min(values+[0]); maximum=max(values+[1]); pts=' '.join(f'{50+i*700/max(1,len(values)-1):.1f},{350-(v-minimum)/(maximum-minimum)*280:.1f}' for i,v in enumerate(values))
 (OUT/name).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="800" height="420"><rect width="800" height="420" fill="white"/><path d="M50 50 V350 H750" fill="none" stroke="gray"/><polyline points="{pts}" fill="none" stroke="#004098" stroke-width="2"/><text x="50" y="395">Sample index; y range [{minimum:.2f}, {maximum:.2f}]</text></svg>')
p=argparse.ArgumentParser();p.add_argument('--speed',type=float,default=12);args=p.parse_args()
rows=read('gps_raw.csv');rows=sorted(rows,key=lambda r:(r['object_id'],r['time']))
unique=[];seen=set()
for row in rows:
 key=tuple(row[k] for k in ['object_id','time','x_m','y_m'])
 if key not in seen:unique.append(row);seen.add(key)
def seconds(t):
 h,m,s=map(int,t.split(':'));return h*3600+m*60+s
kept=[];rejected=[];last={}
for r in unique:
 prev=last.get(r['object_id']);speed=0
 if prev:
  dt=seconds(r['time'])-seconds(prev['time']);speed=math.hypot(float(r['x_m'])-float(prev['x_m']),float(r['y_m'])-float(prev['y_m']))/dt if dt>0 else float('inf')
 r={**r,'speed_mps':round(speed,3),'accepted':speed<=args.speed}
 if r['accepted']:kept.append(r);last[r['object_id']]=r
 else:rejected.append(r)
save(kept,'clean.csv');save(rejected,'rejected.csv');plot([float(r['x_m']) for r in kept])
report({'raw':len(rows),'unique':len(unique),'clean':len(kept),'rejected':len(rejected),'speed_threshold':args.speed})
