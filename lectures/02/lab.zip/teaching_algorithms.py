"""可运行的逐步教学实现；只用 Python 标准库。
python3 teaching_algorithms.py knn --k 2
python3 teaching_algorithms.py pca --angle -45
python3 teaching_algorithms.py matching --transition 8
python3 teaching_algorithms.py rdp --epsilon .6
python3 teaching_algorithms.py gps --speed 12 --gap 120
每个 emit 对应网页里一个步骤；返回值为最终结果。
"""
import math
import json
import argparse
import csv
from pathlib import Path


def knn(query=1, k=2, emit=lambda *args: None):
    donors = [(1, 0, 10), (2, 2, 14), (3, 6, 40)]
    distances = []
    emit('input', {'query': query, 'k': k, 'donors': donors})
    for record_id, a, b in donors:
        distance = abs(query - a)
        distances.append([distance, record_id, b])
        emit('distance', {'id': record_id, 'distance': distance})
    distances.sort(key=lambda r: (r[0], r[1]))
    emit('sort', {'order': [r[1] for r in distances]})
    chosen = distances[:k]
    emit('select', {'ids': [r[1] for r in chosen]})
    total = 0
    for distance, record_id, b in chosen:
        total += b
        emit('sum', {'id': record_id, 'total': total})
    estimate = total / len(chosen)
    emit('result', {'estimate': estimate})
    return {'estimate': estimate, 'ids': [r[1] for r in chosen]}


def pca(angle=-45, emit=lambda *args: None):
    points = [[2, 0], [0, 2], [3, 1], [1, 3]]
    n = len(points)
    emit('input', {'points': points})
    mean = [sum(q[j] for q in points) / n for j in range(2)]
    emit('mean', {'mean': mean})
    centered = []
    for i, q in enumerate(points):
        centered.append([q[j] - mean[j] for j in range(2)])
        emit('center', {'id': i, 'centered': centered[-1]})
    outer_sum = [[0.0, 0.0], [0.0, 0.0]]
    for i, q in enumerate(centered):
        for a in range(2):
            for b in range(2):
                outer_sum[a][b] += q[a] * q[b]
        emit('outer', {'id': i, 'sum': [row[:] for row in outer_sum]})
    covariance = [[v / (n - 1) for v in row] for row in outer_sum]
    emit('covariance', {'covariance': covariance})
    a, b, c = covariance[0][0], covariance[0][1], covariance[1][1]
    delta = math.sqrt((a - c) ** 2 + 4 * b * b)
    eigenvalues = [(a + c + delta) / 2, (a + c - delta) / 2]
    emit('eigen', {'eigenvalues': eigenvalues})
    # 本例 b 非零；显式归一化二维特征向量。
    axis = [b, eigenvalues[0] - a]
    norm = math.hypot(*axis)
    axis = [-v / norm for v in axis]  # 取第一个分量为正的符号
    emit('axis', {'axis': axis})
    w = [math.cos(math.radians(angle)), math.sin(math.radians(angle))]
    emit('direction', {'angle': angle, 'w': w})
    scores = []
    for i, q in enumerate(centered):
        scores.append(sum(q[j] * w[j] for j in range(2)))
        emit('project', {'id': i, 'score': scores[-1]})
    reconstruction, sse = [], 0
    for i, z in enumerate(scores):
        r = [mean[j] + z * w[j] for j in range(2)]
        reconstruction.append(r)
        error = sum((points[i][j] - r[j]) ** 2 for j in range(2))
        sse += error
        emit('reconstruct', {'id': i, 'point': r, 'error': error, 'sse': sse})
    ratio = sum(z * z for z in scores) / (n - 1) / sum(eigenvalues)
    emit('result', {'ratio': ratio, 'sse': sse})
    return {'scores': scores, 'reconstruction': reconstruction, 'sse': sse,
            'ratio': ratio, 'covariance': covariance, 'eigenvalues': eigenvalues}


def matching(transition=8, emit=lambda *args: None):
    emission = [0, 2]
    values, back = [emission[:]], [[None, None]]
    emit('input', {'emission': emission, 'transition': transition})
    emit('initialize', {'values': values[0]})
    for t in range(1, 3):
        row, predecessors = [], []
        for j in range(2):
            candidates = []
            for i in range(2):
                cost = 0 if i == j == 1 else transition
                candidates.append(values[t - 1][i] + cost)
                emit('candidate', {'t': t, 'j': j, 'i': i, 'candidate': candidates[-1]})
            previous = min(range(2), key=lambda i: (candidates[i], i))
            row.append(emission[j] + candidates[previous])
            predecessors.append(previous)
            emit('update', {'t': t, 'j': j, 'value': row[-1], 'previous': previous})
        values.append(row)
        back.append(predecessors)
    end = min(range(2), key=lambda j: (values[-1][j], j))
    path = [end]
    emit('terminal', {'end': end, 'cost': values[-1][end]})
    for t in range(2, 0, -1):
        end = back[t][end]
        path.insert(0, end)
        emit('backtrack', {'t': t - 1, 'state': end})
    emit('result', {'path': path, 'cost': min(values[-1])})
    return {'path': path, 'cost': min(values[-1]), 'values': values, 'back': back}


def rdp(epsilon=.6, emit=lambda *args: None):
    points = [[0, 0], [1, .2], [2, 2], [3, .2], [4, 0]]
    keep = {0, len(points) - 1}
    emit('input', {'points': points, 'epsilon': epsilon})

    def visit(a, b, depth=0):
        emit('enter', {'a': a, 'b': b, 'depth': depth})
        if b - a <= 1:
            emit('leaf', {'a': a, 'b': b})
            return
        dx, dy = points[b][0] - points[a][0], points[b][1] - points[a][1]
        maximum, index = -1, None
        for i in range(a + 1, b):
            denominator = dx * dx + dy * dy
            u = ((points[i][0] - points[a][0]) * dx + (points[i][1] - points[a][1]) * dy) / denominator if denominator else 0
            u = max(0, min(1, u))
            foot = [points[a][0] + u * dx, points[a][1] + u * dy]
            distance = math.hypot(points[i][0] - foot[0], points[i][1] - foot[1])
            if distance > maximum:
                maximum, index = distance, i  # 相同距离保留较早点
            emit('distance', {'a': a, 'b': b, 'id': i, 'u': u, 'foot': foot, 'distance': distance})
        split = maximum > epsilon
        emit('decision', {'a': a, 'b': b, 'id': index, 'maximum': maximum, 'split': split})
        if split:
            keep.add(index)
            visit(a, index, depth + 1)
            visit(index, b, depth + 1)
        emit('return', {'a': a, 'b': b, 'keep': sorted(keep)})

    visit(0, len(points) - 1)
    emit('result', {'keep': sorted(keep)})
    return {'keep': sorted(keep)}


def gps(speed=12, gap=120, emit=lambda *args: None):
    with (Path(__file__).parent / 'data/gps_raw.csv').open(encoding='utf-8-sig') as f:
        rows = [dict(r, source_id=i + 1) for i, r in enumerate(csv.DictReader(f))]
    emit('input', {'count': len(rows)})
    rows.sort(key=lambda r: (r['object_id'], r['time'], r['source_id']))
    emit('sort', {'ids': [r['source_id'] for r in rows]})
    seen, last, segments = set(), {}, {}
    kept, rejected, duplicates = [], [], []
    seconds = lambda t: sum(int(v) * u for v, u in zip(t.split(':'), [3600, 60, 1]))
    for r in rows:
        source = r['source_id']
        key = (r['object_id'], r['time'], float(r['x_m']), float(r['y_m']))
        duplicate = key in seen
        emit('duplicate', {'id': source, 'duplicate': duplicate})
        if duplicate:
            duplicates.append(source)
            continue
        seen.add(key)
        previous = last.get(r['object_id'])
        dt = seconds(r['time']) - seconds(previous['time']) if previous else None
        distance = math.hypot(float(r['x_m']) - float(previous['x_m']), float(r['y_m']) - float(previous['y_m'])) if previous else None
        v = distance / dt if previous and dt > 0 else (math.inf if previous else 0)
        emit('speed', {'id': source, 'previous': previous['source_id'] if previous else None,
                       'dt': dt, 'distance': distance, 'speed': v if math.isfinite(v) else None})
        accepted = v <= speed
        if accepted:
            segment = segments.get(r['object_id'], 1) + int(previous is not None and dt > gap)
            segments[r['object_id']] = segment
            last[r['object_id']] = r
            kept.append(source)
        else:
            rejected.append(source)
        emit('decision', {'id': source, 'accepted': accepted, 'last': last.get(r['object_id'], {}).get('source_id'),
                          'segment': segments.get(r['object_id'], 1)})
    result = {'kept': kept, 'rejected': rejected, 'duplicates': duplicates}
    emit('result', result)
    return result


def impute(method='mean', emit=lambda *args: None):
    observed = [2, 3, 4, 100]
    emit('input', {'observed': observed, 'method': method})
    ordered = sorted(observed)
    emit('sort', {'ordered': ordered})
    total = 0
    for i, value in enumerate(observed):
        total += value
        emit('sum', {'id': i, 'value': value, 'total': total})
    mean = total / len(observed)
    median = (ordered[1] + ordered[2]) / 2
    emit('statistics', {'mean': mean, 'median': median})
    estimate = mean if method == 'mean' else median
    emit('result', {'estimate': estimate, 'filled': observed + [estimate]})
    return {'estimate': estimate, 'filled': observed + [estimate]}


def signal(window=3, z=3, emit=lambda *args: None):
    raw = [10, 11, 10, 12, 11, 50, 12, 11, 10, 12, 11]
    emit('input', {'raw': raw, 'window': window})
    smoothed = []
    for i in range(len(raw)):
        values = raw[max(0, i-window+1):i+1]
        emit('window', {'id': i, 'values': values})
        average = sum(values) / len(values)
        smoothed.append(average)
        emit('average', {'id': i, 'average': average})
    score = (68 - 50) / 5  # 独立参考算例，非从上方序列拟合
    emit('zscore', {'value': 68, 'mean': 50, 'std': 5, 'score': score})
    flag = abs(score) > z
    emit('decision', {'score': score, 'threshold': z, 'flag': flag})
    emit('result', {'smoothed': smoothed, 'score': score, 'flag': flag})
    return {'smoothed': smoothed, 'score': score, 'flag': flag}


def scale(leak='train', emit=lambda *args: None):
    values = [10, 20, 30, 40]
    emit('input', {'values': values, 'leak': leak})
    fit = values if leak == 'all' else values[:3]
    low, high = min(fit), max(fit)
    emit('fit', {'fit': fit, 'low': low, 'high': high})
    scaled = []
    for i, value in enumerate(values):
        transformed = (value-low)/(high-low)
        scaled.append(transformed)
        emit('transform', {'id': i, 'value': value, 'scaled': transformed})
    mean = sum(fit)/len(fit)
    std = math.sqrt(sum((v-mean)**2 for v in fit)/len(fit))
    emit('standardize', {'mean': mean, 'std': std, 'test_z': (40-mean)/std})
    codes = []
    for category in ['A', 'B']:
        code = [int(category == c) for c in ['A', 'B']]
        codes.append(code)
        emit('encode', {'category': category, 'code': code})
    emit('result', {'scaled': scaled, 'test_z': (40-mean)/std, 'codes': codes})
    return {'scaled': scaled, 'test_z': (40-mean)/std, 'codes': codes}


def interpolate(alpha=.5, gap=120, emit=lambda *args: None):
    start, end = [800, 200], [930, 240]
    emit('input', {'start': start, 'end': end})
    interval = 3 * 60  # 08:07 - 08:04，单位秒
    emit('interval', {'interval': interval})
    split = interval > gap
    emit('decision', {'interval': interval, 'gap': gap, 'split': split})
    emit('weight', {'alpha': alpha, 'elapsed': interval*alpha})
    estimate = []
    for j in range(2):
        value = (1-alpha)*start[j] + alpha*end[j]
        estimate.append(value)
        emit('coordinate', {'id': j, 'value': value})
    emit('result', {'estimate': estimate, 'split': split})
    return {'estimate': estimate, 'split': split}


def aggregate(cell=250, window=180, count='points', emit=lambda *args: None):
    # 固定使用12 m/s、120秒的清洗结果，独立于GPS页当前滑块。
    kept = gps(12, 120)['kept']
    with (Path(__file__).parent / 'data/gps_raw.csv').open(encoding='utf-8-sig') as f:
        rows = [dict(r, source_id=i+1) for i, r in enumerate(csv.DictReader(f))]
    rows = sorted((r for r in rows if r['source_id'] in kept), key=lambda r: (r['object_id'],r['time'],r['source_id']))
    emit('input', {'count': len(rows), 'cell': cell, 'window': window})
    groups = {}
    for r in rows:
        gx, gy = math.floor(float(r['x_m'])/cell), math.floor(float(r['y_m'])/cell)
        h, m, s = map(int, r['time'].split(':'))
        tw = math.floor((h*3600+m*60+s)/window)
        key = f'{gx}/{gy}/{tw}'
        emit('assign', {'id': r['source_id'], 'gx': gx, 'gy': gy, 'tw': tw, 'key': key})
        group = groups.setdefault(key, {'points': 0, 'devices': set()})
        group['points'] += 1
        group['devices'].add(r['object_id'])
        emit('increment', {'key': key, 'points': group['points'], 'devices': len(group['devices'])})
    output = [{'key': key, 'points': g['points'], 'devices': len(g['devices'])} for key, g in groups.items()]
    emit('result', {'groups': output, 'count': count})
    return {'groups': output, 'count': count}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('method', choices=['knn', 'pca', 'matching', 'rdp', 'gps', 'impute', 'signal', 'scale', 'interpolate', 'aggregate'])
    parser.add_argument('--k', type=int, default=2)
    parser.add_argument('--query', type=float, default=1)
    parser.add_argument('--angle', type=float, default=-45)
    parser.add_argument('--transition', type=float, default=8)
    parser.add_argument('--epsilon', type=float, default=.6)
    parser.add_argument('--speed', type=float, default=12)
    parser.add_argument('--gap', type=float, default=120)
    parser.add_argument('--method', choices=['mean', 'median'], default='mean', dest='impute_method')
    parser.add_argument('--window', type=int, default=None)
    parser.add_argument('--z', type=float, default=3)
    parser.add_argument('--leak', choices=['train', 'all'], default='train')
    parser.add_argument('--alpha', type=float, default=.5)
    parser.add_argument('--cell', type=float, default=250)
    parser.add_argument('--count', choices=['points','devices'], default='points')
    args = parser.parse_args()
    numeric = [args.query, args.angle, args.transition, args.epsilon, args.speed, args.gap, args.z, args.alpha, args.cell]
    if not all(math.isfinite(v) for v in numeric) or not 1 <= args.k <= 3 or min(args.transition, args.epsilon, args.speed, args.gap) < 0:
        parser.error('参数须有限；K在1—3之间；代价、容差、速度和间隔非负')
    params = {'knn': {'query': args.query, 'k': args.k}, 'pca': {'angle': args.angle},
              'matching': {'transition': args.transition}, 'rdp': {'epsilon': args.epsilon},
              'gps': {'speed': args.speed, 'gap': args.gap}}.get(args.method, {})
    if args.method == 'impute': params = {'method': args.impute_method}
    elif args.method == 'signal': params = {'window': args.window or 3, 'z': args.z}
    elif args.method == 'scale': params = {'leak': args.leak}
    elif args.method == 'interpolate': params = {'alpha': args.alpha, 'gap': args.gap}
    elif args.method == 'aggregate': params = {'cell': args.cell, 'window': args.window or 180, 'count': args.count}
    if args.window is not None and args.window <= 0 or args.cell <= 0 or not 0 <= args.alpha <= 1:
        parser.error('窗口与格网边长须为正，alpha在0—1之间')
    events = []
    output = globals()[args.method](**params, emit=lambda action, state: events.append({'action': action, 'state': state}))
    print(json.dumps({'steps': events, 'result': output}, ensure_ascii=False, indent=2, allow_nan=False))
