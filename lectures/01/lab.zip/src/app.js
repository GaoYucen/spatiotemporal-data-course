'use strict';
const $ = id => document.getElementById(id);
const C = {cyan:'#5edfff',mint:'#89ebbe',violet:'#b5a2ff',gold:'#ffd18a',pink:'#ff99b7',mute:'#a2b3c9'};
const MODULES = D.curriculum.modules;
let stage=0, playing=false, lastFrame=0;
const state = {record:'raw',clean:false,minute:480,station:0,window:60,unit:'count',shuffle:0,
  space:'similarity',similarity:false,lag:0,pattern:0,patternReveal:false,
  forecastStation:0,hour:8,issue:'on_hour',forecastReveal:false,supplement:5,eventOrder:'returns_last',evidence:false,industry:0,candidate:0,workflowReveal:false};
const fmt = m => `${String(Math.floor(m/60)).padStart(2,'0')}:${String(Math.floor(m%60)).padStart(2,'0')}`;
const nfmt = n => Number.isInteger(n)?String(n):Number(n).toFixed(1);
const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const maxOf = arr => Math.max(1,...arr);
const table = (headers,rows) => '<thead><tr>'+headers.map(h=>`<th>${esc(h)}</th>`).join('')+'</tr></thead><tbody>'+rows.map(row=>'<tr>'+row.map(v=>`<td>${esc(v)}</td>`).join('')+'</tr>').join('')+'</tbody>';

function chart(id,series,options={}) {
  const W=780,H=options.height||220,L=43,R=15,T=16,B=32;
  const visible=series.flatMap(s=>s.values.filter(v=>v!==null));
  let ymin=options.ymin===undefined?Math.min(0,...visible):options.ymin;
  let ymax=options.ymax===undefined?Math.max(5,...visible)*1.12:options.ymax;
  if(ymax===ymin)ymax=ymin+1;
  const count=Math.max(...series.map(s=>s.values.length));
  const xmax=options.xmax===undefined?Math.max(1,count-1):options.xmax;
  const x=v=>L+(W-L-R)*v/xmax, y=v=>T+(H-T-B)*(ymax-v)/(ymax-ymin);
  let html=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(options.label||'时空数据图表')}">`;
  for(let i=0;i<=3;i++) {let v=ymin+(ymax-ymin)*i/3;html+=`<path d="M${L} ${y(v)}H${W-R}" stroke="#30435a" opacity=".7"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" fill="${C.mute}" font-size="11">${nfmt(v)}</text>`}
  const ticks=options.ticks||Array.from({length:Math.min(5,count)},(_,i)=>Math.round(xmax*i/Math.max(1,Math.min(5,count)-1)));
  ticks.forEach(v=>{html+=`<text x="${x(v)}" y="${H-8}" text-anchor="middle" fill="${C.mute}" font-size="11">${esc(options.xformat?options.xformat(v):v)}</text>`});
  series.forEach(s=>{
    const xs=s.xs||s.values.map((_,i)=>i);
    if(s.bar) {
      const bw=Math.max(2,(W-L-R)/(options.barCount||count)*.68);
      s.values.forEach((v,i)=>{if(v===null)return;html+=`<rect x="${x(xs[i])-bw/2}" y="${Math.min(y(v),y(0))}" width="${bw}" height="${Math.abs(y(v)-y(0))}" rx="2" fill="${s.color}" opacity=".7"/>`});
    } else {
      let paths=[],current=[];
      s.values.forEach((v,i)=>{if(v===null){if(current.length)paths.push(current);current=[];return}if(s.step&&current.length)current.push([x(xs[i]),current[current.length-1][1]]);current.push([x(xs[i]),y(v)])});if(current.length)paths.push(current);
      paths.forEach(p=>{html+=`<path d="${p.map((pt,i)=>(i?'L':'M')+pt.join(' ')).join(' ')}" fill="none" stroke="${s.color}" stroke-width="${s.width||2.6}" ${s.dash?'stroke-dasharray="6 5"':''} stroke-linecap="round" stroke-linejoin="round"/>`});
      if(s.dots)s.values.forEach((v,i)=>{if(v!==null)html+=`<circle cx="${x(xs[i])}" cy="${y(v)}" r="4" fill="${s.color}"/>`});
    }
  });
  (options.flags||[]).forEach(f=>{html+=`<circle cx="${x(f.x)}" cy="${y(f.y)}" r="7" fill="none" stroke="${C.pink}" stroke-width="2"/>`});
  if(options.marker!==undefined){const pos=Math.min(xmax,Math.max(0,options.marker));html+=`<path d="M${x(pos)} ${T}V${H-B}" stroke="#fff" stroke-dasharray="4 5" opacity=".75"/>`}
  html+='</svg>';$(id).innerHTML=html;
}

function stop(){playing=false;$('play').textContent='▶ 播放'}
function showStage(index){stop();stage=Math.min(MODULES.length-1,Math.max(0,index));const [id,title,sub,pages]=MODULES[stage];
  MODULES.forEach(([key],i)=>{$(key).hidden=i!==stage;document.querySelector(`[data-stage="${i}"]`).classList.toggle('active',i===stage)});
  $('stageNumber').textContent=`EXPERIMENT ${String(stage+1).padStart(2,'0')} / ${String(MODULES.length).padStart(2,'0')}`;
  $('stageTitle').textContent=title;$('stageSub').textContent=sub;$('slideRef').textContent=pages;
  $('progress').textContent=`${stage+1} / ${MODULES.length} · 左右方向键切换实验`;$('prev').disabled=stage===0;$('next').disabled=stage===MODULES.length-1;
  render();
}
function render(){[renderRecords,renderObserve,renderOrder,renderSpace,renderPattern,renderForecast,renderInventory,renderEvidence,renderWorkflow][stage]()}

function renderRecords(){
  document.querySelectorAll('[data-record]').forEach(b=>b.classList.toggle('active',b.dataset.record===state.record));
  ['raw','matrix','od'].forEach((key,i)=>{$(['recordRaw','recordMatrix','recordOd'][i]).hidden=key!==state.record});
  $('rawCount').textContent=D.raw_count.toLocaleString();$('cleanCount').textContent=D.clean_count.toLocaleString();$('errorCount').textContent=D.raw_count-D.clean_count;
  $('rawTable').innerHTML='<thead><tr><th>编号</th><th>借出时间</th><th>归还时间</th><th>起点</th><th>终点</th></tr></thead><tbody>'+D.example.map((r,i)=>`<tr class="${state.clean&&i>=3?'highlight':''}"><td>${esc(r.trip_id)}</td><td>${esc(r.start_time.slice(5))}</td><td>${esc(r.end_time.slice(5))}</td><td>${esc(r.start_station)}</td><td>${esc(r.end_station||'缺失')}</td></tr>`).join('')+'</tbody>';
  $('cleanResult').hidden=!state.clean;$('cleanReveal').textContent=state.clean?'隐藏清洗解释':'检查并显示清洗结果';
  $('cleanResult').textContent=Object.entries(D.audit).map(([reason,n])=>`${reason} ${n}条`).join(' · ')+'。黄色行为本实验预设错误；原始CSV完整保留。';
  const headers=['小时',...D.stations.map(s=>s.id)];
  $('matrixTable').innerHTML=table(headers,D.hourly.slice(6,12).map((r,i)=>[`${i+6}:00—${i+7}:00`,...r]));
  $('odTable').innerHTML=table(['起点↓ 终点→',...D.stations.map(s=>s.id)],D.od.map((r,i)=>[D.stations[i].id,...r]));
  document.querySelectorAll('#matrixTable tbody td:not(:first-child)').forEach(td=>{td.style.background=`rgba(94,223,255,${.06+Math.min(1,Number(td.textContent)/45)*.55})`});
  document.querySelectorAll('#odTable tbody td:not(:first-child)').forEach(td=>{td.style.background=`rgba(181,162,255,${.05+Math.min(1,Number(td.textContent)/90)*.55})`});
  $('odScope').textContent=`10月25日全天${D.day_total}次借车；每条记录进入一个OD格子，矩阵总和等于全天次数。`;
  let net='<svg viewBox="0 0 860 540" style="width:100%;height:260px" role="img" aria-label="起终点流动网络"><defs><marker id="arrowOd" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0L10 5L0 10Z" fill="#6d9db3"/></marker></defs>';
  D.od.forEach((row,i)=>row.forEach((v,j)=>{if(!v||i===j)return;const a=D.stations[i],b=D.stations[j],dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy),ex=b.x-30*dx/len,ey=b.y-30*dy/len;net+=`<path d="M${a.x} ${a.y} Q430 ${i<j?200:350} ${ex} ${ey}" fill="none" stroke="${a.color}" opacity=".35" stroke-width="${1+Math.log1p(v)}" marker-end="url(#arrowOd)"/>`}));
  D.stations.forEach(s=>{net+=`<circle cx="${s.x}" cy="${s.y}" r="28" fill="#172b40" stroke="${s.color}" stroke-width="2"/><text x="${s.x}" y="${s.y+6}" text-anchor="middle" fill="${s.color}" font-size="18">${s.id}</text>`});$('odNetwork').innerHTML=net+'</svg>';
}

const NS='http://www.w3.org/2000/svg';
function element(name,attrs,parent){const el=document.createElementNS(NS,name);Object.entries(attrs).forEach(([k,v])=>el.setAttribute(k,v));parent.append(el);return el}
const nodes=D.stations.map((s,i)=>{const g=element('g',{role:'button',tabindex:0,'aria-label':s.name},$('mapStations'));g.style.cursor='pointer';g.addEventListener('click',()=>{state.station=i;renderObserve()});g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();state.station=i;renderObserve()}});const ring=element('circle',{cx:s.x,cy:s.y,r:42,fill:s.color,opacity:.09},g);const circle=element('circle',{cx:s.x,cy:s.y,r:26,fill:'#11273b',stroke:s.color},g);const text=element('text',{x:s.x,y:s.y+6,'text-anchor':'middle',fill:s.color,'font-size':18,'font-weight':600},g);const label=element('text',{x:s.x,y:s.y-57,'text-anchor':'middle',fill:'#edf5ff','font-size':18},g);label.textContent=s.name;return{ring,circle,text}});
function observationBuckets(){const n=state.window/15;return Array.from({length:96/n},(_,k)=>Array.from({length:5},(_,s)=>D.quarter.slice(k*n,(k+1)*n).reduce((v,r)=>v+r[s],0)))}
function renderObserve(){const buckets=observationBuckets(),k=Math.floor(state.minute/state.window),counts=buckets[k],factor=state.unit==='rate'?60/state.window:1,values=counts.map(n=>n*factor),max=maxOf(values),start=k*state.window;
  $('clock').textContent=fmt(state.minute);$('mapTime').value=Math.floor(state.minute);$('window').value=state.window;$('unit').value=state.unit;
  $('windowTotal').textContent=counts.reduce((a,b)=>a+b,0);$('windowTotalLabel').textContent='当前窗口借车总次数（非速率）';$('hotStation').textContent=D.stations[counts.indexOf(Math.max(...counts))].name;
  $('windowRange').textContent=`${fmt(start)}—${fmt(start+state.window)} · ${state.unit==='rate'?'平均速率：次/小时':'窗口计数：次'}`;
  nodes.forEach((n,i)=>{n.ring.setAttribute('r',38+25*Math.sqrt(values[i]/max));n.circle.setAttribute('r',25+22*Math.sqrt(values[i]/max));n.circle.setAttribute('stroke-width',i===state.station?4:1.5);n.text.textContent=nfmt(values[i])});
  $('ranking').innerHTML=values.map((value,i)=>({value,i})).sort((a,b)=>b.value-a.value).map(({value,i})=>`<div class="barrow"><div class="row between small"><span>${D.stations[i].name}</span><span>${nfmt(value)} ${state.unit==='rate'?'次/小时':'次'}</span></div><div class="bartrack"><div class="barfill" style="width:${100*value/max}%;background:${D.stations[i].color}"></div></div></div>`).join('');
  $('dayChartTitle').textContent=D.stations[state.station].name+' · 全天借车节律';$('chartUnit').textContent=state.unit==='rate'?'纵轴：平均次/小时':`纵轴：次/${state.window}分钟窗口`;
  chart('dayChart',[{values:buckets.map(r=>r[state.station]*factor),xs:buckets.map((_,i)=>(i+.5)*state.window/60),color:D.stations[state.station].color,bar:true}],{height:160,xmax:24,ticks:[0,3,6,9,12,15,18,21,24],marker:state.minute/60,barCount:buckets.length,label:'全天借车计数或平均速率'});
  renderFlow();
}
function renderFlow(){const active=D.routes.filter(r=>r[2]<=state.minute&&r[3]>state.minute);$('tripCount').textContent=active.length;
  const links=new Map();active.forEach(r=>links.set(r[0]+'-'+r[1],[r[0],r[1]]));
  $('flowPaths').innerHTML=[...links.values()].map(([i,j])=>{const a=D.stations[i],b=D.stations[j];return`<path d="M${a.x} ${a.y}Q430 280 ${b.x} ${b.y}" fill="none" stroke="${a.color}" opacity=".24"/>`}).join('');
  $('flowParticles').innerHTML=active.map(r=>{const a=D.stations[r[0]],b=D.stations[r[1]],p=(state.minute-r[2])/(r[3]-r[2]),q=1-p;return`<circle cx="${q*q*a.x+2*q*p*430+p*p*b.x}" cy="${q*q*a.y+2*q*p*280+p*p*b.y}" r="4" fill="${a.color}"/>`}).join('');
}
function renderOrder(){const original=D.order.original,shuffled=D.order.variants[state.shuffle],a=D.order.original_stats,b=D.order.variant_stats[state.shuffle];const max=Math.max(...original)*1.2;
  chart('orderOriginal',[{values:original,color:C.cyan,dots:true}],{xmax:3,ymax:max,ticks:[0,1,2,3],xformat:v=>v+1});
  chart('orderShuffled',[{values:shuffled,color:C.violet,dots:true}],{xmax:3,ymax:max,ticks:[0,1,2,3],xformat:v=>v+1});
  $('originalNumbers').innerHTML=original.map(v=>`<span class="pill">${v}</span>`).join('');$('shuffledNumbers').innerHTML=shuffled.map(v=>`<span class="pill">${v}</span>`).join('');
  $('orderTotal').textContent=a.total;$('orderMean').textContent=a.mean;$('orderMax').textContent=a.max;
  $('roughness').textContent=`相邻小时绝对差的均值：原顺序 ${a.roughness.toFixed(2)} 次；当前顺序 ${b.roughness.toFixed(2)} 次。汇总相同，变化过程不同。`;
}
function renderSpace(){const isLag=state.space==='lag';$('similarityView').hidden=isLag;$('lagView').hidden=!isLag;document.querySelectorAll('[data-space]').forEach(b=>b.classList.toggle('active',b.dataset.space===state.space));
  chart('similarityChart',D.spatial.curves.map((v,i)=>({values:v,color:[C.cyan,C.gold,C.violet][i]})),{xmax:23,ticks:[0,4,8,12,16,20,23]});
  $('similarityResult').hidden=!state.similarity;$('similarityReveal').textContent=state.similarity?'隐藏相关性':'揭晓曲线相关性';$('similarityResult').textContent=`Pearson相关：A与B ${D.spatial.correlations[0].toFixed(2)}；A与E ${D.spatial.correlations[1].toFixed(2)}。仅描述本构造曲线。`;
  const lag=D.spatial.lags[state.lag];$('lag').value=state.lag;$('lagLabel').textContent=lag.lag+'分钟';
  chart('lagChart',[{values:lag.departure,color:C.cyan,dots:true},{values:lag.arrival_aligned,color:C.mint,dots:true,dash:true}],{xmax:8,ticks:[0,2,4,6,8],ymax:36});
  $('lagScore').textContent=`前移 ${lag.lag} 分钟；比较 ${lag.departure.length} 个重叠窗口，相关系数 ${lag.r.toFixed(2)}。${lag.lag===15?'与本实验设定的15分钟行程一致。':'滑到15分钟，检验设定的时间差。'}`;
}
function renderPattern(){const example=D.pattern.cases[state.pattern];$('patternCase').value=state.pattern;
  chart('patternChart',[{values:example.values,color:C.cyan,bar:true},{values:D.pattern.means,color:C.violet},{values:D.pattern.upper,color:C.gold,dash:true}],{xmax:24,ticks:[0,4,8,12,16,20,24],flags:example.flags.map(h=>({x:h,y:example.values[h]})),label:'图书馆各小时计数与历史阈值'});
  $('patternFlags').textContent=example.flags.length?`规则标记的候选小时：${example.flags.map(h=>`${String(h).padStart(2,'0')}:00`).join('、')}。需要核查原因。`:'本规则未标出候选；这不证明没有异常。';
  $('patternCause').hidden=!state.patternReveal;$('patternCause').textContent=example.cause;$('patternReveal').textContent=state.patternReveal?'隐藏模拟原因':'核查本情景的模拟原因';
}
function renderForecast(){const mode=D.forecast.find(v=>v.id===state.issue),h=state.hour,s=state.forecastStation,early=state.issue==='ten_early',r=mode.hours[h];
  $('forecastStation').value=s;$('forecastHour').value=h;$('issue').value=state.issue;
  $('forecastCutoff').textContent=`站在 ${r.issue_time}，预测10月25日 ${fmt(h*60)}—${fmt((h+1)*60)} 的${D.stations[s].name}借车次数。`;
  $('lastLabel').textContent=early?'A 最近完整小时（h−2）':'A 最近完整小时（h−1）';$('predLast').textContent=r.last[s];$('predDaily').textContent=r.daily[s];$('predActual').textContent=state.forecastReveal?r.actual[s]:'?';
  $('forecastError').textContent=state.forecastReveal?`绝对误差 A ${Math.abs(r.last[s]-r.actual[s])} / B ${Math.abs(r.daily[s]-r.actual[s])}`:'先猜再揭晓';$('forecastReveal').textContent=state.forecastReveal?'隐藏真实值':'揭晓真实值';
  const lastKnown=h-(early?1:0);const past=D.hourly.map((row,i)=>i<lastKnown||(state.forecastReveal&&i===h)?row[s]:null);
  chart('forecastChart',[{values:past,xs:past.map((_,i)=>i+.5),color:C.cyan,bar:true}],{height:175,xmax:24,ticks:[0,4,8,12,16,20,24],marker:h-(early?1/6:0),barCount:24,label:'发布时点之前可用的小时与揭晓的目标值'});
  $('availability').textContent=early?`紧邻目标的前一小时尚未结束。已观测其前50分钟 ${r.partial[s]} 次，但不能当作完整小时；A改用更早的完整小时。`:'紧邻目标的前一小时刚结束，可以使用完整计数。目标小时真实值只能在事后评价。';
  $('forecastMetrics').innerHTML='<table><thead><tr><th>站点</th><th>A</th><th>B</th></tr></thead><tbody>'+mode.metrics.map((v,i)=>`<tr ${i===s?'style="color:var(--cyan)"':''}><td>${D.stations[i].name}</td><td>${v.last.toFixed(2)}</td><td>${v.daily.toFixed(2)}</td></tr>`).join('')+'</tbody></table><div class="chartnote">单位：次/小时；越小越好。</div>';
}
function renderInventory(){const scenario=D.inventory[state.eventOrder],r=scenario.cases[state.supplement];$('eventOrder').value=state.eventOrder;$('supplement').value=state.supplement;$('supplementLabel').textContent=state.supplement+'辆';
  $('plannedFinal').textContent=r.planned_final+'辆';$('actualFinal').textContent=r.final_stock+'辆';$('lostRequests').textContent=r.lost;$('lostCard').classList.toggle('bad',r.lost>0);$('lostCard').classList.toggle('good',r.lost===0);
  chart('inventoryChart',[{values:r.trace.map(t=>t.stock),xs:r.trace.map(t=>t.minute),color:C.mint,step:true},{values:r.trace.map(t=>t.planned),xs:r.trace.map(t=>t.minute),color:C.pink,step:true,dash:true}],{height:190,xmax:60,ticks:[0,15,30,45,60],ymin:Math.min(-2,r.minimum_planned-1),label:'借还顺序下的库存变化'});
  $('inventoryConclusion').textContent=r.all_constraints?`本简化情景满足全部条件：15次请求全部服务，09:00剩${r.final_stock}辆（至少2辆）。`:`尚未满足全部条件：${r.lost?`${r.lost}次请求未满足；`:''}${r.final_stock<2?'末时库存不足2辆。':'实际末时有车，也不代表此前没有缺车。'}`;
  $('inventoryMinimum').textContent=`当前顺序的最小可行补车量：${scenario.minimum_supplement}辆。末时公式仅要求5辆；还要检查全过程。`;
}
function renderEvidence(){
  $('evidenceReveal').textContent=state.evidence?'隐藏额外核查结果':'检查库存、请求与采集状态';
  $('evidenceCards').innerHTML=D.evidence.map(r=>`<div class="choice"><div class="sectionlabel">情景 ${r.id}</div><small>借车日志条数</small><div class="hero-number">0</div>${state.evidence?`<h3>${r.name}</h3><p class="explain">初始库存 ${r.stock}辆 · 借车请求 ${r.requests}次<br>实际成功 ${r.served}次 · 采集${r.logger?'正常':'中断'}</p><div class="outcome">${r.conclusion}</div>`:'<p class="mute">没有更多信息，<br>可以断定没有需求吗？</p>'}</div>`).join('');
}
function renderWorkflow(){
  const industry=D.workflow.industries[state.industry],candidate=D.workflow.candidates[state.candidate];
  $('industry').value=state.industry;$('candidate').value=state.candidate;
  $('industryDetail').innerHTML=`<h3>${industry.task}</h3><p class="explain">工作方向：${industry.role}</p><p class="explain">数据：${industry.data}</p><div class="outcome">证据：${industry.evidence}</div>`;
  $('candidateText').textContent=candidate.text;$('workflowResult').hidden=!state.workflowReveal;
  $('workflowResult').innerHTML=candidate.checks.map(v=>`<p style="color:${v.ok?C.mint:C.gold}">${v.ok?'✓':'△'} ${v.label}</p>`).join('');
  $('workflowCheck').textContent=state.workflowReveal?'隐藏核查结果':'检查候选答复';
}

function resetCurrent(){stop();switch(stage){case 0:state.record='raw';state.clean=false;break;case 1:Object.assign(state,{minute:480,station:0,window:60,unit:'count'});$('speed').value='45';break;case 2:state.shuffle=0;break;case 3:state.space='similarity';state.similarity=false;state.lag=0;break;case 4:state.pattern=0;state.patternReveal=false;break;case 5:state.forecastStation=0;state.hour=8;state.issue='on_hour';state.forecastReveal=false;break;case 6:state.supplement=5;state.eventOrder='returns_last';break;case 7:state.evidence=false;break;case 8:state.industry=0;state.candidate=0;state.workflowReveal=false;break}render()}

$('navigation').innerHTML=MODULES.map(([key,title,sub,pages],i)=>`<button data-stage="${i}"><span class="number">${String(i+1).padStart(2,'0')}</span>${title}<small>${pages.replace('PPT ','').replace(' · 扩展','')}</small></button>`).join('')+'<div class="navnote">建议按PPT分段打开。<br>每个实验先猜，再操作。<br>“重置本实验”恢复默认。<br>所有情景均可离线运行。</div>';
$('industry').innerHTML=D.workflow.industries.map((r,i)=>`<option value="${i}">${r.name}</option>`).join('');
$('forecastStation').innerHTML=D.stations.map((s,i)=>`<option value="${i}">${s.name}</option>`).join('');$('forecastHour').innerHTML=Array.from({length:24},(_,h)=>`<option value="${h}">${fmt(h*60)}—${fmt((h+1)*60)}</option>`).join('');
document.querySelectorAll('[data-stage]').forEach(b=>b.addEventListener('click',()=>showStage(Number(b.dataset.stage))));
document.querySelectorAll('[data-record]').forEach(b=>b.onclick=()=>{state.record=b.dataset.record;renderRecords()});
document.querySelectorAll('[data-space]').forEach(b=>b.onclick=()=>{state.space=b.dataset.space;renderSpace()});
document.querySelectorAll('[data-jump]').forEach(b=>b.onclick=()=>{stop();state.minute=Number(b.dataset.jump);renderObserve()});
$('cleanReveal').onclick=()=>{state.clean=!state.clean;renderRecords()};$('window').onchange=e=>{state.window=Number(e.target.value);renderObserve()};$('unit').onchange=e=>{state.unit=e.target.value;renderObserve()};
$('mapTime').oninput=e=>{stop();state.minute=Number(e.target.value);renderObserve()};$('play').onclick=()=>{playing=!playing;if(playing&&state.minute>=1439)state.minute=0;$('play').textContent=playing?'Ⅱ 暂停':'▶ 播放'};
$('shuffle').onclick=()=>{state.shuffle=(state.shuffle+1)%D.order.variants.length;renderOrder()};$('similarityReveal').onclick=()=>{state.similarity=!state.similarity;renderSpace()};$('lag').oninput=e=>{state.lag=Number(e.target.value);renderSpace()};
$('patternCase').onchange=e=>{state.pattern=Number(e.target.value);state.patternReveal=false;renderPattern()};$('patternReveal').onclick=()=>{state.patternReveal=!state.patternReveal;renderPattern()};
for(const id of ['forecastStation','forecastHour','issue'])$(id).onchange=e=>{if(id==='forecastStation')state.forecastStation=Number(e.target.value);if(id==='forecastHour')state.hour=Number(e.target.value);if(id==='issue')state.issue=e.target.value;state.forecastReveal=false;renderForecast()};
$('forecastReveal').onclick=()=>{state.forecastReveal=!state.forecastReveal;renderForecast()};$('eventOrder').onchange=e=>{state.eventOrder=e.target.value;renderInventory()};$('supplement').oninput=e=>{state.supplement=Number(e.target.value);renderInventory()};$('setFive').onclick=()=>{state.supplement=5;renderInventory()};$('findFeasible').onclick=()=>{state.supplement=D.inventory[state.eventOrder].minimum_supplement;renderInventory()};
$('industry').onchange=e=>{state.industry=Number(e.target.value);renderWorkflow()};$('candidate').onchange=e=>{state.candidate=Number(e.target.value);state.workflowReveal=false;renderWorkflow()};$('workflowCheck').onclick=()=>{state.workflowReveal=!state.workflowReveal;renderWorkflow()};
$('evidenceReveal').onclick=()=>{state.evidence=!state.evidence;renderEvidence()};$('reset').onclick=resetCurrent;$('prev').onclick=()=>showStage(stage-1);$('next').onclick=()=>showStage(stage+1);
$('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen()}catch{$('fullscreen').textContent='请用浏览器全屏菜单'}};
document.addEventListener('fullscreenchange',()=>{$('fullscreen').textContent=document.fullscreenElement?'⛶ 退出全屏':'⛶ 全屏'});
document.addEventListener('keydown',e=>{if(e.target!==document.body)return;if(e.key==='ArrowRight'){e.preventDefault();showStage(stage+1)}if(e.key==='ArrowLeft'){e.preventDefault();showStage(stage-1)}if(e.code==='Space'&&stage===1){e.preventDefault();$('play').click()}});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stop()});
let previousBucket=-1,previousSecond=-1;
function animate(t){const dt=Math.min((t-lastFrame)/1000,.1);lastFrame=t;if(playing&&stage===1){state.minute=Math.min(1439,state.minute+dt*Number($('speed').value));const bucket=Math.floor(state.minute/state.window),second=Math.floor(state.minute);if(bucket!==previousBucket||second!==previousSecond){renderObserve();previousBucket=bucket;previousSecond=second}else{renderFlow();$('clock').textContent=fmt(state.minute);$('mapTime').value=Math.floor(state.minute)}if(state.minute>=1439)stop()}requestAnimationFrame(animate)}
showStage(0);requestAnimationFrame(animate);
