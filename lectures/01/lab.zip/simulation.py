"""独立的合成数据与基线函数；由同目录demo.py调用。"""
from pathlib import Path
from datetime import datetime, timedelta
from collections import Counter
import csv
import json
import random
import math

ROOT = Path(__file__).resolve().parent
SEED = 20261103
STATIONS = [
    {'id': 'S1', 'name': '宿舍区', 'x': 190, 'y': 170, 'color': '#55deff'},
    {'id': 'S2', 'name': '教学楼', 'x': 660, 'y': 145, 'color': '#b5a0ff'},
    {'id': 'S3', 'name': '图书馆', 'x': 650, 'y': 385, 'color': '#ffca75'},
    {'id': 'S4', 'name': '食堂', 'x': 185, 'y': 395, 'color': '#78efbd'},
    {'id': 'S5', 'name': '体育馆', 'x': 430, 'y': 465, 'color': '#ff91b3'},
]
START = datetime(2026, 10, 12)  # 14个连续教学模拟日；不区分周末
DAYS = 14


def poisson(rng, mean):
    """Knuth算法：抽取非负计数，避免第三方依赖。"""
    limit, product, k = math.exp(-mean), 1.0, 0
    while product > limit:
        k += 1
        product *= rng.random()
    return k - 1


def expected_trips(station, hour):
    """人为设定校园日节律，不代表任何真实校园。"""
    peaks = [((8, 45), (14, 17)), ((12, 30), (17, 44)),
             ((12, 12), (21, 33)), ((13, 34), (19, 28)), ((19, 32), (21, 16))]
    return 0.5 + sum(a * math.exp(-0.5 * ((hour - h) / 1.2) ** 2)
                     for h, a in peaks[station])


def generate_records():
    rng = random.Random(SEED)
    records = []
    for day in range(DAYS):
        for hour in range(24):
            for sid in range(5):
                # 每日波动独立抽样；预测不读取生成公式。
                n = poisson(rng, expected_trips(sid, hour) * rng.uniform(.85, 1.15))
                for _ in range(n):
                    depart = START + timedelta(days=day, hours=hour, minutes=rng.randrange(60), seconds=rng.randrange(60))
                    target = rng.choice([i for i in range(5) if i != sid])
                    # 早晨宿舍借车流向教学楼，傍晚教学楼借车流向宿舍。
                    if sid == 0 and 6 <= hour <= 10 and rng.random() < .8:
                        target = 1
                    elif sid == 1 and 16 <= hour <= 19 and rng.random() < .8:
                        target = 0
                    arrive = depart + timedelta(minutes=rng.randint(4, 20))
                    records.append({'trip_id': f'T{len(records)+1:06}', 'start_time': depart.isoformat(' '),
                                    'end_time': arrive.isoformat(' '), 'start_station': f'S{sid+1}',
                                    'end_station': f'S{target+1}'})
    # 显式加入可审计的错误：三条重复、两条时间倒置、一条站点缺失。
    records.extend(dict(r) for r in records[:3])
    for i in range(2):
        bad = dict(records[10+i], trip_id=f'BAD_TIME_{i}')
        bad['end_time'] = (datetime.fromisoformat(bad['start_time']) - timedelta(minutes=5)).isoformat(' ')
        records.append(bad)
    records.append(dict(records[20], trip_id='BAD_STATION', end_station=''))
    return records


def clean_records(records):
    seen, clean, audit = set(), [], Counter()
    valid = {s['id'] for s in STATIONS}
    for row in records:
        if row['trip_id'] in seen:
            audit['重复编号'] += 1
            continue
        seen.add(row['trip_id'])
        if row['start_station'] not in valid or row['end_station'] not in valid:
            audit['站点缺失或无效'] += 1
            continue
        try:
            start, end = datetime.fromisoformat(row['start_time']), datetime.fromisoformat(row['end_time'])
        except ValueError:
            audit['时间格式错误'] += 1
            continue
        if end <= start:
            audit['结束早于开始'] += 1
            continue
        clean.append(row)
    return clean, dict(audit)


def aggregate(records, minutes=60):
    """完整时间网格；本模拟假定记录完整，真实数据不能一律把缺记录填零。"""
    buckets = [[0] * 5 for _ in range(DAYS * 24 * 60 // minutes)]
    for row in records:
        t = datetime.fromisoformat(row['start_time'])
        i = int((t - START).total_seconds() // (60 * minutes))
        if 0 <= i < len(buckets):
            buckets[i][int(row['start_station'][1:])-1] += 1
    return buckets


def evaluate(hourly):
    """前7天为历史期，后7天滚动一步预测；预测h时只用h之前的观测。"""
    result = []
    for station in range(5):
        actual = [hourly[h][station] for h in range(168, 336)]
        last = [hourly[h-1][station] for h in range(168, 336)]
        daily = [hourly[h-24][station] for h in range(168, 336)]
        mae = lambda pred: round(sum(abs(a-p) for a, p in zip(actual, pred)) / len(actual), 3)
        result.append({'station': STATIONS[station]['name'], 'last_mae': mae(last), 'daily_mae': mae(daily),
                       'actual': actual, 'last': last, 'daily': daily})
    return result

