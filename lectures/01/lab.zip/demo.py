"""增强版课堂实验：python3 demo.py。仅使用标准库，所有输出限定在本文件目录。"""
from pathlib import Path
from datetime import timedelta, datetime
import csv
import json
import random
import statistics
import math
from simulation import (STATIONS, START, DAYS, SEED, generate_records,
                        clean_records, aggregate, evaluate)

ROOT = Path(__file__).resolve().parent


def correlation(a, b):
    """Pearson相关；常数序列没有可定义的相关系数。"""
    ma, mb = statistics.mean(a), statistics.mean(b)
    numerator = sum((x-ma)*(y-mb) for x, y in zip(a, b))
    denominator = math.sqrt(sum((x-ma)**2 for x in a) * sum((y-mb)**2 for y in b))
    return round(numerator/denominator, 4) if denominator else None


def order_experiment():
    original = [2, 3, 12, 13]
    variants = [[12, 2, 13, 3]]
    rng = random.Random(SEED)
    while len(variants) < 8:
        permutation = rng.sample(original, len(original))
        if permutation != original and permutation not in variants:
            variants.append(permutation)
    def stats(values):
        return {'total': sum(values), 'mean': statistics.mean(values), 'max': max(values),
                'roughness': round(statistics.mean(abs(b-a) for a,b in zip(values, values[1:])), 3)}
    return {'original': original, 'variants': variants, 'original_stats': stats(original),
            'variant_stats': [stats(v) for v in variants]}


def spatial_experiment():
    # 独立构造图，不是PPT图表的数值重建，也不是S1—S5的地理实测。
    a = [1,1,2,4,8,16,28,35,20,9,4,3,4,7,12,7,3,2,2,1,1,1,1,1]
    b = [1,1,1,1,2,2,3,4,5,10,22,30,13,6,8,20,35,28,12,5,3,2,1,1]
    e = [1,2,2,5,9,15,26,33,22,10,3,4,4,8,11,8,4,2,3,1,1,2,1,1]
    departure = [2,3,8,18,30,16,7,2,0]
    arrival = [0] + departure[:-1]  # 所有行程恰好15分钟的独立构造实验。
    lags = []
    for lag in range(4):
        x = departure[:len(departure)-lag] if lag else departure[:]
        y = arrival[lag:] if lag else arrival[:]
        lags.append({'lag': lag*15, 'departure': x, 'arrival_aligned': y, 'r': correlation(x,y)})
    return {'curves': [a,b,e], 'correlations': [correlation(a,b),correlation(a,e)],
            'departure': departure, 'arrival': arrival, 'lags': lags}


def forecast_cases(clean, hourly):
    """完整小时基线。提前10分钟发布时，上一完整小时只能取h-2。"""
    last_day = 13*24
    cases = []
    for issue in ['on_hour', 'ten_early']:
        offset = 1 if issue == 'on_hour' else 2
        matrix = []
        metrics = []
        for hour in range(24):
            h = last_day+hour
            cutoff = START+timedelta(hours=h, minutes=0 if issue=='on_hour' else -10)
            partial_start = START+timedelta(hours=h-1)
            partial = [0]*5
            if issue == 'ten_early':
                for r in clean:
                    t = datetime.fromisoformat(r['start_time'])
                    if partial_start <= t < cutoff:
                        partial[int(r['start_station'][1:])-1] += 1
            matrix.append({'issue_time': cutoff.strftime('%m-%d %H:%M'),
                           'last': hourly[h-offset], 'daily': hourly[h-24],
                           'actual': hourly[h], 'partial': partial})
        for station in range(5):
            mae = lambda lag: round(sum(abs(hourly[h][station]-hourly[h-lag][station]) for h in range(168,336))/168,3)
            metrics.append({'last': mae(offset), 'daily': mae(24)})
        cases.append({'id': issue, 'hours': matrix, 'metrics': metrics})
    return cases


def pattern_experiment(hourly):
    station = 2  # 图书馆，固定目标；不声称进行了聚类。
    means = [statistics.mean(hourly[d*24+h][station] for d in range(7)) for h in range(24)]
    std = [max(2, statistics.stdev(hourly[d*24+h][station] for d in range(7))) for h in range(24)]
    original = [r[station] for r in hourly[-24:]]
    changed = original[:]
    changed[14] += 40
    cases = []
    for label,values,cause in [('正常回放',original,'基础合成记录，没有额外注入。'),
                               ('情景 A',changed,'模拟真实活动增加：14时额外增加40次借车事件。'),
                               ('情景 B',changed,'模拟采集重复：14时汇总计数额外增加40，真实活动未变。')]:
        flags = [h for h in range(24) if abs(values[h]-means[h]) > 3*std[h]]
        cases.append({'label': label, 'values': values, 'flags': flags, 'cause': cause})
    return {'means': means, 'upper': [means[h]+3*std[h] for h in range(24)],
            'cases': cases, 'station': '图书馆'}


def event_schedule(order):
    borrows = [(2+3*i, 'borrow', 1) for i in range(15)]
    if order == 'returns_first':
        events = [(1,'return',4)] + borrows
    elif order == 'returns_last':
        events = borrows + [(55,'return',4)]
    else:
        events = borrows + [(m,'return',1) for m in [10,25,40,55]]
    return sorted(events, key=lambda e:(e[0],0 if e[1]=='return' else 1))


def simulate_inventory(supplement, order):
    """请求不足时不服务、不让物理库存变负；另列假定全服务的账面库存。"""
    stock = 8+supplement
    planned = stock
    served = lost = 0
    trace = [{'minute':0, 'stock':stock, 'planned':planned, 'lost':0, 'event':'补车完成'}]
    for minute, kind, count in event_schedule(order):
        if kind == 'return':
            stock += count
            planned += count
            name = f'归还{count}辆'
        else:
            planned -= count
            if stock >= count:
                stock -= count
                served += count
                name = '借车成功'
            else:
                lost += count
                name = '请求未满足'
        trace.append({'minute':minute,'stock':stock,'planned':planned,'lost':lost,'event':name})
    trace.append(dict(trace[-1], minute=60, event='09:00'))
    return {'supplement':supplement,'order':order,'served':served,'lost':lost,
            'final_stock':stock,'planned_final':planned,'minimum_planned':min(t['planned'] for t in trace),
            'all_constraints':lost==0 and stock>=2,'trace':trace}


def inventory_experiment():
    result = {}
    for order in ['returns_first','interleaved','returns_last']:
        cases = [simulate_inventory(x,order) for x in range(21)]
        result[order] = {'cases':cases,'minimum_supplement':next(r['supplement'] for r in cases if r['all_constraints'])}
    return result


def workflow_experiment():
    """预设的流程与核查卡；没有调用或模拟真实大模型推理。"""
    return {
      'industries': [
        {'name':'出行与地图服务','task':'需求预测、到达时间估计、路径规划','role':'预测算法 / 地图算法','data':'历史出行、路网与预测时已知信息','evidence':'留出后续日期，对比基线；路径问题另查可通行与时间约束。'},
        {'name':'配送物流与供应链','task':'运力调度、配送路径、仓网选址','role':'运筹优化 / 数据科学','data':'订单、站点、车辆与服务时间窗','evidence':'检查容量、服务时间与执行成本，预测误差不能替代调度效果。'},
        {'name':'零售与本地生活','task':'客流分析、门店选址、位置推荐','role':'商业数据分析 / 推荐算法','data':'门店、客流、位置与行为记录','evidence':'明确覆盖、隐私与评价对象；对新时间或新地点留出测试。'},
        {'name':'能源与工业物联网','task':'负荷预测、设备监测、异常预警','role':'预测算法 / 工业数据分析','data':'带时间与位置的传感器序列、设备状态','evidence':'区分故障与采集错误，检查预警提前量、误报与漏报。'},
        {'name':'遥感与城市服务','task':'地表变化、灾害识别、设施空间分析','role':'遥感算法 / GIS开发','data':'影像、空间图层与带时间的地面参照','evidence':'检查坐标与时间对应，使用独立区域、日期或地面观测。'}],
      'candidates': [
        {'text':'宿舍区借车次数最多，所以明早一定缺车，应立即补5辆。',
         'checks':[{'ok':False,'label':'借车次数不能直接推出缺车，还缺初始库存与归还。'},
                   {'ok':False,'label':'5辆来自PPT独立假设情景，不能迁移成这个问题的结论。'}]},
        {'text':'在07:50，使用今天07:00—08:00的完整借车次数预测08:00—09:00。',
         'checks':[{'ok':False,'label':'发布时点不满足信息可得性：07:50还不知道最后10分钟。'},
                   {'ok':True,'label':'目标对象、时段和数量已经明确，但输入需要调整。'}]},
        {'text':'先明确发布时点，预测下一小时借车次数并和同期基线比较。若要判断缺车，再补充库存、归还及全过程约束。',
         'checks':[{'ok':True,'label':'区分数量预测与缺车决策。'},
                   {'ok':True,'label':'要求核查输入时点、基线与库存约束；这是合理计划，还不是已执行结果。'}]}
      ]}


def build():
    raw = generate_records()
    clean,audit = clean_records(raw)
    hourly = aggregate(clean)
    day_start = START+timedelta(days=13)
    day_rows = [r for r in clean if datetime.fromisoformat(r['start_time']).date()==day_start.date()]
    routes = []
    od = [[0]*5 for _ in STATIONS]
    for r in day_rows:
        start,end = datetime.fromisoformat(r['start_time']),datetime.fromisoformat(r['end_time'])
        i,j=int(r['start_station'][1:])-1,int(r['end_station'][1:])-1
        routes.append([i,j,round((start-day_start).total_seconds()/60,2),round((end-day_start).total_seconds()/60,2)])
        od[i][j] += 1
    payload = {'seed':SEED,'date':'2026-10-25','stations':STATIONS,'raw_count':len(raw),'clean_count':len(clean),
               'audit':audit,'example':raw[:3]+raw[-6:],'clean_example':clean[:8],
               'quarter':aggregate(clean,15)[-96:],'hourly':hourly[-24:], 'previous':hourly[-48:-24],
               'od':od,'day_total':len(day_rows),'routes':routes,'order':order_experiment(),
               'spatial':spatial_experiment(),'forecast':forecast_cases(clean,hourly),
               'pattern':pattern_experiment(hourly),'inventory':inventory_experiment(),
               'curriculum':json.loads((ROOT/'src/curriculum.json').read_text(encoding='utf-8')),
               'workflow':workflow_experiment(),
               'evidence':[
                   {'id':'A','recorded':0,'stock':8,'requests':0,'served':0,'logger':True,'name':'确实无人借车','conclusion':'有车、采集正常，但没有请求。'},
                   {'id':'B','recorded':0,'stock':0,'requests':8,'served':0,'logger':True,'name':'没有车可借','conclusion':'有8次请求但库存为0；成功借车记录没有反映未满足需求。'},
                   {'id':'C','recorded':0,'stock':8,'requests':8,'served':8,'logger':False,'name':'采集系统中断','conclusion':'实际发生8次成功借车，但日志未采集；业务量应标为未知。'}]}
    data=ROOT/'data'
    data.mkdir(exist_ok=True)
    for name,rows in [('原始借还记录.csv',raw),('清洗后借还记录.csv',clean)]:
        with (data/name).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(raw[0]));writer.writeheader();writer.writerows(rows)
    (data/'实验数据.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    source=ROOT/'src'
    template=(source/'interface.html').read_text(encoding='utf-8')
    html=template.replace('__STYLE__',(source/'style.css').read_text(encoding='utf-8'))
    html=html.replace('__DATA__',json.dumps(payload,ensure_ascii=False)).replace('__SCRIPT__',(source/'app.js').read_text(encoding='utf-8'))
    (ROOT/'开始演示.html').write_text(html,encoding='utf-8')
    print('已生成增强版：',ROOT/'开始演示.html')
    print('9个实验；原始',len(raw),'条，有效',len(clean),'条；仅写入本文件夹。')
    return payload


if __name__ == '__main__':
    build()
